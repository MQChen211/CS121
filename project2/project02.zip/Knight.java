import java.util.*;

public class Knight extends Piece {
    public Knight(Color c) {this.pieceColor= c;}
    // implement appropriate methods

    public String toString(){
        if(this.color() == Color.BLACK){return "bn";}
        else {return "wn";}
    }

    public List<String> moves(Board b, String loc) {
        List<String> possibleMoves = new ArrayList<String>();

        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        String tryloc;

        //int row = loc.charAt(1);
        //char col = loc.charAt(0);
        //int numcol = col - '0';

        int xoffset[] = {1,1,2,2,-1,-1,-2,-2}; //change col
        int yoffset[] = {2,-2,1,-1,2,-2,1,-1}; //change row

        for(int i = 0; i<8; i++){
            tryloc = "" + (char) (col + 'a' + xoffset[i]) + (char) (row + '1' + yoffset[i]);
            //int newCol = numcol + xoffset[i];
            //int newRow = row + yoffset[i];
            if(b.isValid(tryloc)){
                if((b.getPiece(tryloc) == null) || (b.getPiece(tryloc).pieceColor != b.getPiece(loc).pieceColor)){
                    possibleMoves.add(tryloc);
                }

            }

        }
        return possibleMoves;







        //8 cases: (col, row) = (2,1),(2,-1),(-2,1),(-2,-1),(1,1),(1,-1),(-1,1),(-1,-1)
        //knight abs(x-y) == 2; abs(x+y == 3)
        //abs(numcol - 97 -row)
        //abs(rownew - row == 1) && abs(colnew - col == 2)
        //abs(rownew - row == 2) && abs(colnew - col == 1)

        /*
        int newCol01 = numcol + 2;
        int newCol02 = numcol - 2;
        int newCol03 = numcol + 1;
        int newCol04 = numcol - 1;
        int r01 = row + 2;
        int r02 = row - 2;
        int r03 = row + 1;
        int r04 = row - 1;
        String newRow01 = Integer.toString(row + 2);
        String newRow02 = Integer.toString(row - 2);
        String newRow03 = Integer.toString(row + 1);
        String newRow04 = Integer.toString(row - 1);

        char newColchar01 = (char)(newCol01 + '0');
        String newLoc01 = newColchar01 + newRow03;
        if((newCol01 >= 97) && (newCol01 <= 104) && (r03 >= 1) && (r03 <= 8)){
            if(b.getPiece(newLoc01) == null){
               possibleMoves.add(newLoc01);
            }
            else if(b.getPiece(newLoc01).pieceColor == b.getPiece(loc).pieceColor){
                return false;
            }
            else{
                possibleMoves.add(newLoc01);
                return false;
            }
        }



        char newColchar01 = (char)(newCol01 + '0');
        String newLoc02 = newColchar01 + newRow04;
        if((newCol01 >= 97) && (newCol01 <= 104) && (newRol04 >= 1) && (newRol04 <= 8)){
            if(b.getPiece(newLol01) == null){
                possibleMoves.add(newLoc02);
            }
            else if(b.getPiece(newLol02).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc02);
                break;
            }
        }

        char newColchar02 = (char)(newCol02 + '0');
        String newLoc03 = newColchar02 + newRow03;
        if((newCol02 >= 97) && (newCol02 <= 104) && (newRol03 >= 1) && (newRol03 <= 8)){
            if(b.getPiece(newLol03) == null){
                possibleMoves.add(newLoc03);
            }
            else if(b.getPiece(newLol03).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc03);
                break;
            }
        }

        char newColchar02 = (char)(newCol02 + '0');
        String newLoc04 = newColchar02 + newRow04;
        if((newCol02 >= 97) && (newCol02 <= 104) && (newRol04 >= 1) && (newRol04 <= 8)){
            if(b.getPiece(newLol04) == null){
                possibleMoves.add(newLoc04);
            }
            else if(b.getPiece(newLol04).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc04);
                break;
            }
        }

        char newColchar03 = (char)(newCol03 + '0');
        String newLoc05 = newColchar03 + newRow01;
        if((newCol03 >= 97) && (newCol03 <= 104) && (newRol01 >= 1) && (newRol01 <= 8)){
            if(b.getPiece(newLol05) == null){
                possibleMoves.add(newLoc05);
            }
            else if(b.getPiece(newLol05).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc05);
                break;
            }
        }

        char newColchar03 = (char)(newCol03 + '0');
        String newLoc06 = newColchar03 + newRow02;
        if((newCol03 >= 97) && (newCol03 <= 104) && (newRol02 >= 1) && (newRol02 <= 8)){
            if(b.getPiece(newLol06) == null){
                possibleMoves.add(newLoc06);
            }
            else if(b.getPiece(newLol06).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc06);
                break;
            }
        }

        char newColchar04 = (char)(newCol04 + '0');
        String newLoc07 = newColchar04 + newRow01;
        if((newCol04 >= 97) && (newCol04 <= 104) && (newRol01 >= 1) && (newRol01 <= 8)){
            if(b.getPiece(newLol07) == null){
                possibleMoves.add(newLoc07);
            }
            else if(b.getPiece(newLol07).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc07);
                break;
            }
        }


        char newColchar04 = (char)(newCol04 + '0');
        String newLoc08 = newColchar04 + newRow02;
        if((newCol04 >= 97) && (newCol04 <= 104) && (newRol02 >= 1) && (newRol02 <= 8)){
            if(b.getPiece(newLol08) == null){
                possibleMoves.add(newLoc08);
            }
            else if(b.getPiece(newLol08).pieceColor == b.getPiece(loc).pieceColor){
                break;
            }
            else{
                possibleMoves.add(newLoc08);
                break;
            }
        }

    return possibleMoves;



        */

	//throw new UnsupportedOperationException();
    }

}

