import java.util.*;

public class Rook extends Piece {
    public Rook(Color c) {
        this.pieceColor = c;
    }

    //this.color.equals(b)
    public String toString() {
        if (this.color() == Color.BLACK) {
            return "br";
        } else {
            return "wr";
        }
    }

    public List<String> moves(Board b, String loc) {


        /*
        public int ifColorSame (Location loc){
            if (loc == null) {
                return 0;
            } else if (b.getPiece(loc).color == this.color) {
                return 1;
            } else return -1;
        }

        public Boolean locInRange (loc) {
        if ( loc.charAt(0) >= 0 && loc.charAt(0) < 8 && loc.charAt(1) >= 0 && loc.charAt(1) < 8;){
            return 1;
        }
        }

        */

        List<String> possibleMoves = new ArrayList<String>();
        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        String trylocu = loc;
        String trylocd = loc;
        String trylocl = loc;
        String trylocr = loc;

        for (int i = 0; i < 8; i++) {
            trylocu = "" + (char) (col + 'a') + (char) (i + '1');
            trylocd = "" + (char) (col + 'a') + (char) (-i + '1');
            if (b.isValid(trylocu)) {
                if ((b.getPiece(trylocu) == null) || (b.getPiece(trylocu).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocu);
                } else {
                    return possibleMoves;
                }
                if ((b.getPiece(trylocd) == null) || (b.getPiece(trylocd).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocd);
                } else {
                    return possibleMoves;
                }
            }
        }


        for (int j = 0; j < 8; j++) {
            trylocl = "" + (char) (j + 'a') + (char) (row + '1');
            trylocr = "" + (char) (-j + 'a') + (char) (row + '1');

            if (b.isValid(trylocu)) {
                if ((b.getPiece(trylocu) == null) || (b.getPiece(trylocu).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocu);
                } else {
                    return possibleMoves;
                }
                if ((b.getPiece(trylocd) == null) || (b.getPiece(trylocd).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocd);
                } else {
                    return possibleMoves;
                }
            }


            return possibleMoves;
        }

    return possibleMoves;}
}








/*



            if (b.getPiece(upstr) == null) {
                possibleMoves.add(upstr);
            } else if (b.getPiece(upstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(upstr);
                break;
            }
        }


        //for loop check up row
        for (int i = row + 1; i <= 8; i++) {
            //String upstr = col.concat(i);  int to char?
            //row int to char
            //char newRow = (char)(i + '0');
            String upstr = String.valueOf(col) + String.valueOf(i);
            //String upstr = col + i;
            if (b.getPiece(upstr) == null) {
                possibleMoves.add(upstr);
            } else if (b.getPiece(upstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(upstr);
                break;
            }
        }

        //for loop check down row
        for (int i = row - 1; i >= 1; i--) {
            //String downstr = col.concat(i);  int to char?
            String downstr = String.valueOf(col) + String.valueOf(i);
            //String downstr = col + i;
            if (b.getPiece(downstr) == null) {
                possibleMoves.add(downstr);
            } else if (b.getPiece(downstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(downstr);
                break;
            }
        }

        //for loop check right col
        for (int i = numcol + 1; i <= 104; i++) {
            //String rCol = i;
            //rCol int to char
            char rCol = (char)(i + '0');
            String rstr = String.valueOf(rCol) + String.valueOf(row);
            //String rstr = rCol + row;
            if (b.getPiece(rstr) == null) {
                possibleMoves.add(rstr);
            } else if (b.getPiece(rstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(rstr);
                break;
            }
        }


        //for loop check left col
        for (int i = numcol - 1; i >= 96; i--) {

            char lCol = (char)(i + '0');
            String lstr = String.valueOf(lCol) + String.valueOf(row);
            //String lstr = lCol + row;
            if (b.getPiece(lstr) == null) {
                possibleMoves.add(lstr);
            } else if (b.getPiece(lstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(lstr);
                break;
            }
        }
    return possibleMoves;

    }

}


*/

    /*

    //candidate canMoveLoc cannot move over the edge:
    // <= 8, >= 0, >= a, <=h
    public List<String> moves(Board b, String loc) {
        List<String> rookCanMove = new ArrayList<String>();
        char col = loc.charAt(0);
        int row = loc.charAt(1);
        String locrow = Integer.toString(row);
        int numcol = (int) col;
        int colmax = 104; //h
        int colmin = 97; //a
        //String asciiCol;
        //asciiCol = string.valiueOf(col);

        //e.g., loc == d3;
        //check row: d1, d2, d4, d5, d6, d7, d8
        for(int i = row + 1; i++; i<=8){
            //int checkRowUp = i + 1; col remains the same == col
            //char curCheckCol = col;
            String curCheckRow = Integer.toString(i);
            String curCheckLoc = col.concat(curCheckRow); //candidate canmove location

            //if current location has same color, cannot go to this current loc,
            //can only go to cur - 1

            if((b.getPiece(curCheckLoc) != null) && (b.getPiece(curCheckLoc).color == this.color)){
                // check if canmoveloc within the range
                String canMoveRow = curCheckRow - 1;
                String canMoveLoc = col.concat(canMoveRow);
                if(((canMoveRow <= 8) || (canMoveRow >= 0)) && (numcol <= 104) || (numcol >= 97))){rookCanMove.add(canMoveLoc);}
                throw new UnsupportedOperationException();
            }

            //if current loc has different color, can go to this loc
            if((b.getPiece(curCheckLoc) != null) && (b.getPiece(curCheckLoc).color != this.color)){
                String canMoveLoc01 = col.concat(curCheckRow);
                if(((canMoveRow <= 8) || (canMoveRow >= 0)) && (numcol <= 104) || (numcol >= 97))){rookCanMove.add(canMoveLoc01);}
                throw new UnsupportedOperationException();
            }

            //if curr loc is null, can go to this loc
            if(b.getPiece(curCheckLoc) == null){
                rookCanMove.add(curCheckLoc);
            }
            throw new UnsupportedOperationException();
        }

        for(int j = row - 1; j--; j>=0){
            String curCheckRow02 = Integer.toString(j);
            String curCheckLoc02 = col.concat(curCheckRow02);
            //int checkRowDown = i - 1; col remains the same == col

            if((b.getPiece(curCheckLoc02) != null) && (b.getPiece(curCheckLoc02).color == this.color)){
                String canMoveRow02 = curCheckRow02 - 1;
                String canMoveLoc02 = col.concat(canMoveRow02);
                if(((canMoveRow02 <= 8) || (canMoveRow02 >= 0)) && (numcol <= 104) || (numcol >= 97))){rookCanMove.add(canMoveLoc02);}
                throw new UnsupportedOperationException();
            }

            //if current loc has different color, can go to this loc
            if((b.getPiece(curCheckLoc02) != null) &&   (b.getPiece(curCheckLoc02).color != this.color)){
                String canMoveLoc03 = col.concat(curCheckRow02);
                if(((canMoveRow02 <= 8) || (canMoveRow02 >= 0)) && (numcol <= 104) || (numcol >= 97))){rookCanMove.add(canMoveLoc03);}
                throw new UnsupportedOperationException();
            }

            //if curr loc is null, can go to this loc
            if(b.getPiece(curCheckLoc02) == null){
                rookCanMove.add(curCheckLoc02);
            }

            throw new UnsupportedOperationException();

        }


        //e.g., loc == d3; check col: a3, b3, c3, e3, f3, g3, h3
        //Check Col
        //int numCurCol = (int) col;
        //int total = numCurCol + 97;
        for(int k = numCurCol + 1; k++; k<= colmax){
            //int checkRowUp = i + 1; col remains the same == col
            String checkCol = string.valueOf(numCurCol);
            String checkLoc = CheckCol.concat(row);

            //if current location has same color, cannot go to this current loc,
            //can only go to cur - 1
            if((b.getPiece(curCheckLoc) != null) && (b.getPiece(checkLoc).color == this.color)){
                String moveCol = string.valueOf(numCurCol - 1);
                String moveLoc = moveCol.concat(checkRow);
                if(((moveCol <= 104) || (moveCol >= 97)) && ((row >= 0)||(row <= 8))){rookCanMove.add(moveLoc);}
                throw new UnsupportedOperationException();
            }

            //if current loc has different color, can go to this loc
            if((b.getPiece(curCheckLoc) != null) && (b.getPiece(CheckLoc).color != this.color)){
                String moveCol02 = string.valueOf(numCurCol);
                String moveLoc02 = moveCol02.concat(checkRow);
                if(((moveCol <= 104) || (moveCol >= 97)) && ((row >= 0)||(row <= 8))){rookCanMove.add(moveLoc);}
                throw new UnsupportedOperationException();
            }

            //if curr loc is null, can go to this loc
            if(b.getPiece(curCheckLoc) == null){
                rookCanMove.add(checkLoc);
            }

            throw new UnsupportedOperationException();
        }


        for(int l = numCurCol - 1; l--; l >= colmin){

            String checkCol02 = string.valueOf(numCurCol);
            String checkRow02 = Integer.toString(row);
            String checkLoc02 = CheckCol02.concat(CheckRow02);

            //if current location has same color, cannot go to this current loc,
            //can only go to cur - 1
            if(b.getPiece(checkLoc02).color == this.color){
                String moveCol02 = string.valueOf(numCurCol - 1);
                String moveLoc02 = moveCol02.concat(checkRow02);
                rookCanMove.add(moveLoc02);
            }

            //if current loc has different color, can go to this loc
            if(b.getPiece(CheckLoc).color != this.color){
                rookCanMove.add(checkLoc02);
            }

            //if curr loc is null, can go to this loc
            if(b.getPiece(curCheckLoc) == null){
                rookCanMove.add(checkLoc02);
            }

            throw new UnsupportedOperationException();
        }




















        //loc: current location, e.g., charAt(0) = a, charAt(1) = 2, location == a2
        //check if spot occupied: b.getPiece(a5), check color: b.getPiece(a5).color, if == this.color, if != this.color

        return rookCanMove;
	//throw new UnsupportedOperationException();
    }


    */


