import java.util.*;

abstract public class Piece {
    public static void registerPiece(PieceFactory pf) {
        pf.getClass();
        //throw new UnsupportedOperationException();
    }



    //e.g., factory:
    //public class KnightFactory implements PieceFactory {
    //    public char symbol() { return 'n'; }
    //    public Piece create(Color c) { return new Knight(c); }

    public Color pieceColor;
    public static Piece createPiece(String name) {
        Piece chessPiece = null;
        Color cname;
        char nameColor = name.charAt(0);
        char nameKind = name.charAt(1);

        List<Character> names = new ArrayList<Character>();
        names.add('k');
        names.add('q');
        names.add('n');
        names.add('b');
        names.add('r');
        names.add('p');

        /*List<String> names = new ArrayList<Stringr>();
        names.add("k");
        names.add("q");
        names.add("n");
        names.add("b");
        names.add("r");
        names.add("p");*/

        if ((name.charAt(0) != 'b') && (name.charAt(0) != 'w') && (!names.contains(name.charAt(1))) ){
            throw new UnsupportedOperationException();
        }


        //decide piece color
        if (nameColor == 'b') {
            cname = Color.BLACK;
        }
        else if (nameColor == 'w') {
            cname = Color.WHITE;
        }
        else{throw new UnsupportedOperationException();}

        //create piece with factory method
        if (nameKind == 'k') {
            chessPiece = new King(cname);
        }
        else if (nameKind == 'g') {
            chessPiece = new Queen(cname);
        }
        else if (nameKind == 'n') {
            chessPiece = new Knight(cname);
        }
        else if (nameKind == 'b') {
            chessPiece = new Bishop(cname);
        }
        else if (nameKind == 'r') {
            chessPiece = new Rook(cname);
        }
        else if (nameKind == 'p') {
            chessPiece = new Pawn(cname);
        }
        else{throw new UnsupportedOperationException();}

        return chessPiece;
    }


    public Color color() {
        return pieceColor;
        // You should write code here and just inherit it in
        // subclasses. For this to work, you should know
        // that subclasses can access superclass fields.
        //throw new UnsupportedOperationException();
    }
    abstract public String toString();

    //not sure return the piece name in the form it appears in the layout file

    abstract public List<String> moves(Board b, String loc);
    //loc: current location, e.g., charAt(0) = a, charAt(1) = 2, location == a2

}
    /*
    public void Piece registerPiece(PieceFactory pf){
        // create a hashmap
        HashMap<String, PieceFactory> pieceRegister = new HashMap<>();
        pieceRegister.put("r", RookFactory);
        pieceRegister.put("q", QueenFactory);
        pieceRegister.put("p", PawnFactory);
        pieceRegister.put("k", KingFactory);
        pieceRegister.put("n", KnightFactory);
        pieceRegister.put("b", BishopFactory);

        return pieceRegister;

    }

    public void Piece createPiece(String name){
        String pieceColor = name.charAt(0);
        String piecekind = name.charAt(1);
        if(pieceRegister.containsKey(piecekind)){
            return pieceRegister.get(piecekind);
        }
        return false;
    }


    */


