import java.util.*;

public class Queen extends Piece {
    public Queen(Color c) {this.pieceColor = c;}
        //throw new UnsupportedOperationException();
    // implement appropriate methods
    //this.color.equals(b)
    public String toString() {
        if (this.color() == Color.BLACK) {
            return "bq";
        }
        else {
            return "wq";
        }
    }

    public List<String> moves(Board b, String loc) {
        List<String> possibleMoves = new ArrayList<>();


        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        String tryUpR;
        String tryUpL;
        String tryLowR;
        String tryLowL;

        String trylocu = loc;
        String trylocd = loc;
        String trylocl = loc;
        String trylocr = loc;


        //move up right
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryUpR = "" + (char) (col + 'a' + i) + (char) (row + '1' + j);
            if (b.isValid(tryUpR)) {
                if (b.getPiece(tryUpR) == null) {
                    possibleMoves.add(tryUpR);
                } else if (b.getPiece(tryUpR).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryUpR);
                } else {
                    return possibleMoves;
                }

            }
        }


        //move upleft
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryUpL = "" + (char) (col + 'a' - i) + (char) (row + '1' + j);
            if (b.isValid(tryUpL)) {
                if (b.getPiece(tryUpL) == null) {
                    possibleMoves.add(tryUpL);
                } else if (b.getPiece(tryUpL).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryUpL);
                } else {
                    return possibleMoves;
                }

            }
        }

        //move lower Reft
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryLowR = "" + (char) (col + 'a' + i) + (char) (row + '1' - j);
            if (b.isValid(tryLowR)) {
                if (b.getPiece(tryLowR) == null) {
                    possibleMoves.add(tryLowR);
                } else if (b.getPiece(tryLowR).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryLowR);
                } else {
                    return possibleMoves;
                }

            }
        }

        //move lower Left
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryLowL = "" + (char) (col + 'a' - i) + (char) (row + '1' - j);
            if (b.isValid(tryLowL)) {
                if (b.getPiece(tryLowL) == null) {
                    possibleMoves.add(tryLowL);
                } else if (b.getPiece(tryLowL).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryLowL);
                } else {
                    return possibleMoves;
                }

            }
        }

        for (int i = 0; i < 8; i++) {
            trylocu = "" + (char) (col + 'a') + (char) (i + '1');
            trylocd = "" + (char) (col + 'a') + (char) (-i + '1');
            if (b.isValid(trylocu)) {
                if ((b.getPiece(trylocu) == null) || (b.getPiece(trylocu).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocu);
                } else {
                    return possibleMoves;
                }
                if ((b.getPiece(trylocd) == null) || (b.getPiece(trylocd).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocd);
                } else {
                    return possibleMoves;
                }
            }
        }


        for (int j = 0; j < 8; j++) {
            trylocl = "" + (char) (j + 'a') + (char) (row + '1');
            trylocr = "" + (char) (-j + 'a') + (char) (row + '1');

            if (b.isValid(trylocu)) {
                if ((b.getPiece(trylocu) == null) || (b.getPiece(trylocu).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocu);
                } else {
                    return possibleMoves;
                }
                if ((b.getPiece(trylocd) == null) || (b.getPiece(trylocd).pieceColor != b.getPiece(loc).pieceColor)) {
                    possibleMoves.add(trylocd);
                } else {
                    return possibleMoves;
                }
            }


            return possibleMoves;
        }



/*
    public List<String> moves(Board b, String loc) {

        ArrayList<String> possibleMoves = new ArrayList<String>();
        int row = loc.charAt(1);
        char col = loc.charAt(0);
        int numcol = col - '0';


        for (int i = row + 1; i <= 8; i++) {
            //String upstr = col.concat(i);  int to char?
            //row int to char
            //char newRow = (char)(i + '0');
            String upstr = String.valueOf(col) + String.valueOf(i);
            //String upstr = col + i;
            if (b.getPiece(upstr) == null) {
                possibleMoves.add(upstr);
            } else if (b.getPiece(upstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(upstr);
                break;
            }
        }

        //for loop check down row
        for (int i = row - 1; i >= 1; i--) {
            //String downstr = col.concat(i);  int to char?
            String downstr = String.valueOf(col) + String.valueOf(i);
            //String downstr = col + i;
            if (b.getPiece(downstr) == null) {
                possibleMoves.add(downstr);
            } else if (b.getPiece(downstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(downstr);
                break;
            }
        }

        //for loop check right col
        for (int i = numcol + 1; i <= 104; i++) {
            //String rCol = i;
            //rCol int to char
            char rCol = (char)(i + '0');
            String rstr = String.valueOf(rCol) + String.valueOf(row);
            //String rstr = rCol + row;
            if (b.getPiece(rstr) == null) {
                possibleMoves.add(rstr);
            } else if (b.getPiece(rstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(rstr);
                break;
            }
        }


        //for loop check left col
        for (int i = numcol - 1; i >= 96; i--) {

            char lCol = (char)(i + '0');
            String lstr = String.valueOf(lCol) + String.valueOf(row);
            //String lstr = lCol + row;
            if (b.getPiece(lstr) == null) {
                possibleMoves.add(lstr);
            } else if (b.getPiece(lstr).pieceColor == b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(lstr);
                break;
            }
        }


        for(int i = row + 1, j = numcol + 1; i <= 8 && j <= 104; i++, j++){
            char newCol = (char)(j + '0');
            //String upR = newCol + i;
            String upR = String.valueOf(newCol) + String.valueOf(i);

            if (b.getPiece(upR) == null) {
                possibleMoves.add(upR);
            } else if (b.getPiece(upR).pieceColor != b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(upR);
                break;
            }
        }


        //move up left
        for(int i = row + 1, j = numcol - 1; i <= 8 && j >= 96; i++, j--){
            char newCol = (char)(j + '0');
            //String upL = newCol + i;
            String upL = String.valueOf(newCol) + String.valueOf(i);

            if (b.getPiece(upL) == null) {
                possibleMoves.add(upL);
            } else if (b.getPiece(upL).pieceColor != b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(upL);
                break;
            }
        }


        //move down right
        for(int i = row - 1, j = numcol + 1; i >= 1 && j <= 104; i--, j++){
            char newCol = (char)(j + '0');
            //String downR = newCol + i;
            String downR = String.valueOf(newCol) + String.valueOf(i);
            if (b.getPiece(downR) == null) {
                possibleMoves.add(downR);
            } else if (b.getPiece(downR).pieceColor != b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(downR);
                break;
            }
        }

        //move down left
        for(int i = row - 1, j = numcol - 1; i >= 1 && j >= 96; i--, j--){
            char newCol = (char)(j + '0');
            //String downL = newCol + i;
            String downL = String.valueOf(newCol) + String.valueOf(i);
            if (b.getPiece(downL) == null) {
                possibleMoves.add(downL);
            } else if (b.getPiece(downL).pieceColor != b.getPiece(loc).pieceColor) {
                break;
            } else {
                possibleMoves.add(downL);
                break;
            }
        }
        */

    return possibleMoves;
    }
    //throw new UnsupportedOperationException();
}

