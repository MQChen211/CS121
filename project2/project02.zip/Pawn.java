import java.util.*;

public class Pawn extends Piece {
    public Pawn(Color c) {this.pieceColor = c;}

        // implement appropriate methods
    public String toString() {
            if (this.color() == Color.BLACK) {
                return "bp";
            }
            else {
                return "wp";
            }
	//throw new UnsupportedOperationException();
    }


    public List<String> moves(Board b, String loc) {

        List<String> possibleMoves = new ArrayList<String>();
        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        String try01;
        String try02;
        String try03;
        String try04;

        try01 = "" + (char) (col + 'a') + (char) (row + '1' + 1); //forward 1 step
        try02 = "" + (char) (col + 'a') + (char) (row + '1' + 2); //forward 2 steps
        try03 = "" + (char) (col + 'a' - 1) + (char) (row + '1' + 1); //capture upleft
        try04 = "" + (char) (col + 'a' + 1) + (char) (row + '1' + 1); //capture upright


        if(this.color() == Color.WHITE ){
            if (b.isValid(try01) && b.isValid(try02)) {
                if ((row == 0) && (b.getPiece(try01) == null)) {
                    possibleMoves.add(try01);
                }
                if ((row == 0) && (b.getPiece(try02) == null)) {
                    possibleMoves.add(try01);
                }
            }

           if((b.isValid(try03)) && (b.getPiece(try03).pieceColor != b.getPiece(loc).pieceColor)){
                possibleMoves.add(try03);
            }

            if((b.isValid(try04)) && (b.getPiece(try04).pieceColor != b.getPiece(loc).pieceColor)){
                possibleMoves.add(try04);
            }
            return possibleMoves;
        }



        if(this.color() == Color.BLACK ){
            if (b.isValid(try01) && b.isValid(try02)) {
                if ((row == 0) && (b.getPiece(try01) == null)) {
                    possibleMoves.add(try01);
                }
                if ((row == 0) && (b.getPiece(try02) == null)) {
                    possibleMoves.add(try02);
                }
            }

            if((b.isValid(try03)) && (b.getPiece(try03).pieceColor != b.getPiece(loc).pieceColor)){
                possibleMoves.add(try03);
            }

            if((b.isValid(try04)) && (b.getPiece(try04).pieceColor != b.getPiece(loc).pieceColor)){
                possibleMoves.add(try04);
            }
            return possibleMoves;
        }
        return possibleMoves;

    }
}