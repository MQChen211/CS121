import java.util.*;
public class Board {
    private Piece[][] pieces = new Piece[8][8];
    private static Board newBoard;

    private Board() {}

    public static Board theBoard() {
        if (newBoard == null){newBoard = new Board();}
        return newBoard;
    }
    // Returns piece at given loc or null if no such piece exists

    public boolean isValid(String loc) {
        int i = loc.charAt(0) - 'a';
        int j = loc.charAt(1) - '1';
        if ((i >= 0) && (i < 8) && (j > 0) && (j < 8)) {
            return true;
        }
        return false;
    }




    public Piece getPiece(String loc) {
        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        //char col = loc.charAt(0);
        //int numcol = col - '0';
        //if(loc.isEmpty()){return null;}
        //else if(this.isValid(loc)){
        if(this.isValid(loc)){
            return this.pieces[col][row];
        }
        throw new UnsupportedOperationException();
    }

    public void addPiece(Piece p, String loc) {
        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        //char col = loc.charAt(0);
        //int numcol = col - '0';
        //int row = loc.charAt(1);
        //if(this.isValid(loc);){pieces[numcol - 97][row]}
        if (this.isValid(loc)) {
            p = pieces[col][row];
        } else {
            throw new UnsupportedOperationException();
        }
    }



    /*public interface BoardListener {
        void onMove(String from, String to, Piece p);
        void onCapture(Piece attacker, Piece captured);
    }*/
    //Piece method
    //abstract public List<String> moves(Board b, String loc);
    public void movePiece(String from, String to) {
        if ((this.isValid(from)) && (this.isValid(to))) {
            Piece p1 = this.getPiece(from);
            Piece p2 = this.getPiece(to);

            //if loc = to is in p1's possiblemoves
            if((p1 != null) && (p1.moves(this, from).contains(to)))
            {
                for (BoardListener bl : blisteners) {
                    this.addPiece(p1, to); //add from piece to toloc
                    this.addPiece(null, from); //remove from piece from fromloc
                    if (p2 == null) {
                        bl.onMove(from, to, p1);
                    } else {
                        bl.onMove(from, to, p1);
                        bl.onCapture(p1, p2);
                    }
                }
            }

        }
        throw new UnsupportedOperationException();
    }


    public void clear() {


        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                this.pieces[i][j] = null;
            }
            //throw new UnsupportedOperationException();
        }


    }

    private List<BoardListener> blisteners = new ArrayList<>();
    public void registerListener(BoardListener bl) {
        blisteners.add(bl);
    }

        /*BoardListener bl = new BoardListener();
        public List<BoardListerner> BoardListeners = new ArrayList<>();
        if ((this.movePiece()) && (!p.to.isEmpty())){
            BoardListeners.add(bl);
            bl.onMove();
            bl.onCapture();
        }
        if ((movePiece() && p.to.isEmpty())){
            BoardListeners.add(bl);
            bl.onMove();
        }
	throw new UnsupportedOperationException();*/



    public void removeListener(BoardListener bl) {
        blisteners.remove(bl);
	//throw new UnsupportedOperationException();
    }

    public void removeAllListeners() {
        blisteners.clear();
	//throw new UnsupportedOperationException();
    }

    //char col = loc.charAt(0);
    //int numcol = col - '0';


    public void iterate(BoardInternalIterator bi) {
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                //String curstr = charCol + i;
                //loc.charAt(0) = charCol;
                //loc.charAt(1) = i;
                //if(this.getPiece() == null){continue;}
                String loc = "" + (char) ('a' + i) + (char) ('1' + j);
                bi.visit(loc, pieces[i][j]);


            }
        }
	//throw new UnsupportedOperationException();
    }
}