import java.util.*;

public class Bishop extends Piece {
    public Bishop(Color c) {this.pieceColor = c;}
    // implement appropriate methods

    public String toString() {
        if(this.color() == Color.BLACK){return "bb";}
        else {return "wb";}
	//throw new UnsupportedOperationException();
    }



    public List<String> moves(Board b, String loc) {
        List<String> possibleMoves = new ArrayList<>();

        //char col = loc.charAt(0);
        //int row = loc.charAt(1);
        //int numcol = col - '0';
        //System.out.println(col);
        //System.out.println(row);
        //System.out.println(numcol);


        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        String tryUpR;
        String tryUpL;
        String tryLowR;
        String tryLowL;


        //move up right
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryUpR = "" + (char) (col + 'a' + i) + (char) (row + '1' + j);
            if (b.isValid(tryUpR)) {
                if (b.getPiece(tryUpR) == null) {
                    possibleMoves.add(tryUpR);
                } else if (b.getPiece(tryUpR).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryUpR);
                } else {
                    return possibleMoves;
                }

            }
        }


        //move upleft
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryUpL = "" + (char) (col + 'a' - i) + (char) (row + '1' + j);
            if (b.isValid(tryUpL)) {
                if (b.getPiece(tryUpL) == null) {
                    possibleMoves.add(tryUpL);
                } else if (b.getPiece(tryUpL).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryUpL);
                } else {
                    return possibleMoves;
                }

            }
        }

        //move lower Reft
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryLowR = "" + (char) (col + 'a' + i) + (char) (row + '1' - j);
            if (b.isValid(tryLowR)) {
                if (b.getPiece(tryLowR) == null) {
                    possibleMoves.add(tryLowR);
                } else if (b.getPiece(tryLowR).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryLowR);
                } else {
                    return possibleMoves;
                }

            }
        }

        //move lower Left
        for (int i = 0, j = 0; i < 8 && j < 8; i++, j++) {
            char newCol = (char) (j + '0');
            tryLowL = "" + (char) (col + 'a' - i) + (char) (row + '1' - j);
            if (b.isValid(tryLowL)) {
                if (b.getPiece(tryLowL) == null) {
                    possibleMoves.add(tryLowL);
                } else if (b.getPiece(tryLowL).pieceColor != b.getPiece(loc).pieceColor) {
                    possibleMoves.add(tryLowL);
                } else {
                    return possibleMoves;
                }

            }
        }
        return possibleMoves;
    }

}