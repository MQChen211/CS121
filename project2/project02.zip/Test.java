public class Test {

    // Run "java -ea Test" to run with assertions enabled (If you run
    // with assertions disabled, the default, then assert statements
    // will not execute!)

    public static void test1() {
	Board b = Board.theBoard();
	Piece.registerPiece(new PawnFactory());
	Piece p = Piece.createPiece("bp");
	b.addPiece(p, "a3");
	assert b.getPiece("a3") == p;
    }


    public static void test2(){
		Board b = Board.theBoard();
		Piece.registerPiece(new KingFactory());
		Piece p1 = Piece.createPiece("bp");
		Piece p2 = Piece.createPiece("wq");
		Piece p3 = Piece.createPiece("br");
		Piece p4 = Piece.createPiece("wr");

		b.addPiece(p1, "a1");
		b.addPiece(p2, "c1");
		b.addPiece(p1, "a2");
		b.addPiece(p2, "c3");

		assert b.getPiece("a1") == p1;
		assert b.getPiece("c1") == p2;
		assert b.getPiece("a2") == p3;
		assert b.getPiece("c2") == p4;

	}


    public static void main(String[] args) {
	test1();
    }

}