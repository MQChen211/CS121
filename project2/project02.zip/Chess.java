import java.io.*;
import java.util.*;


public class Chess {
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java Chess layout moves");
		}
		Piece.registerPiece(new KingFactory());
		Piece.registerPiece(new QueenFactory());
		Piece.registerPiece(new KnightFactory());
		Piece.registerPiece(new BishopFactory());
		Piece.registerPiece(new RookFactory());
		Piece.registerPiece(new PawnFactory());
		Board.theBoard().registerListener(new Logger());
		// args[0] is the layout file name
		// args[1] is the moves file name
		// Put your code to read the layout file and moves files
		// here.




	Board b = Board.theBoard();
	//charAt() to get letter from a string
	//List<String> list = new List<String>();

	//layouts and moves
	List<Character> column = new ArrayList<Character>(Arrays.asList('a','b','c','d','e','f','h'));
	List<Character> row = new ArrayList<Character>(Arrays.asList('1','2','3','4','5','6','7','8'));
	List<Character> pieceKind = new ArrayList<Character>(Arrays.asList('k','q','n','b','r','p'));
	List<Character> color = new ArrayList<Character>(Arrays.asList('b','w'));


	try

	{
		BufferedReader readLayout = new BufferedReader(new FileReader("layout1"));
		String sl = readLayout.readLine();
		while (sl != null) {
			if (sl.charAt(0) == '#') {
				sl = readLayout.readLine();
				continue;
			}

			if (sl.length() != 5) {
				throw new UnsupportedOperationException();
			}


			//if((String.valueOf(sl.charAt(0)) == null) || (String.valueOf(sl.charAt(1)) == null) || (String.valueOf(sl.charAt(3))==null) || (String.valueOf(sl.charAt(4))==null) ){throw new UnsupportedOperationException();}
		    if (column.contains(sl.charAt(0)) && row.contains(sl.charAt(1)) && color.contains(sl.charAt(3)) && pieceKind.contains(sl.charAt(4))) {
				System.out.println(sl);
			} else {
				throw new UnsupportedOperationException();
			}

			String pname = sl.substring(3, 5);
			Piece p = Piece.createPiece(pname);

			String location = sl.substring(0, 2);
			b.addPiece(p, location);


		}
		readLayout.close();
	} catch (IOException el)
	{
		el.printStackTrace();
	}




		try {
			BufferedReader readLayout = new BufferedReader(new FileReader("moves1"));
			String sl = readLayout.readLine();
			while(sl != null) {
				if(sl.charAt(0) == '#'){
					sl = readLayout.readLine();
					continue;
				}
				if(sl.length() != 5){throw new UnsupportedOperationException();}
				if(sl.charAt(2) != '='){throw new UnsupportedOperationException();}


				else{
					if(column.contains(sl.charAt(0)) && row.contains(sl.charAt(1)) && color.contains(sl.charAt(3)) && pieceKind.contains(sl.charAt(4))) {
						System.out.println(sl);
					}
				}
				throw new UnsupportedOperationException();
			}
			readLayout.close();
		}catch(IOException el){
			el.printStackTrace();
			//return;
		}




		try {
			BufferedReader readMoves = new BufferedReader(new FileReader(args[1]));
			String sm = readMoves.readLine();
			while(sm != null) {

				if(String.valueOf(sm.charAt(0)) == "#"){
					sm = readMoves.readLine();
					continue;
				}
				if(sm.length() != 5){throw new UnsupportedOperationException();}
				if(String.valueOf(sm.charAt(2)) != "-"){throw new UnsupportedOperationException();}

				if(column.contains(sm.charAt(0)) && row.contains(sm.charAt(1)) && column.contains(3) && row.contains(4)){
						System.out.println(sm);
				}
				else{throw new UnsupportedOperationException();}

				//throw new UnsupportedOperationException();

				String from = sm.substring(0,2);
				String to = sm.substring(3,5);
				b.movePiece(from, to);
				sm = readMoves.readLine();

			}
			readMoves.close();
		}catch(IOException em){
			em.printStackTrace();
		}




	// Leave the following code at the end of the simulation:
	System.out.println("Final board:");
	Board.theBoard().iterate(new BoardPrinter());
    }
}
