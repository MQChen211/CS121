import java.util.*;

public class King extends Piece {
    public King(Color c) {this.pieceColor = c;}


    public String toString() {
        if(this.color() == Color.BLACK){return "bk";}
        else{return "wk";}
	//throw new UnsupportedOperationException();
    }




    //public String toString() {
        //if(this.color() == 'b'){return "bk";}
        //if(this.color() == 'w'){return "wk";}
        //throw new UnsupportedOperationException();
    //}








    public List<String> moves(Board b, String loc) {
        List<String> possibleMoves = new ArrayList<String>();
        int col = loc.charAt(0) - 'a';
        int row = loc.charAt(1) - '1';
        String tryloc = loc;
        //char col = loc.charAt(0);
        //int numcol = col - '0';
        for(int i = -1; i <= 1; i++){
            for(int j = -1; j <= 1; j++){
                if((i != 0) && (j != 0)){
                    tryloc = "" + (char) (col + 'a' + i) + (char) (row + '1' + j);
                    if(b.isValid(tryloc)){

                        if((b.getPiece(tryloc) == null)){
                            possibleMoves.add(tryloc);}
                        else if(b.getPiece(tryloc).pieceColor != b.getPiece(loc).pieceColor){
                            possibleMoves.add(tryloc);
                        }
                        else{
                            return possibleMoves;
                        }
                    }

                }

            }
        }
        return possibleMoves;

    }
}



        /*
        //check all spots around loc, i = row, j = col
        for(int i = -1; i <= 1; i++){
            int newRow = row + i;

            if((newRow >= 1) && (newRow <= 8)){
                for(int j = -1; j <= 1; j++){
                    int newCol = numcol + j; // int to char

                    if((newCol >= 97) && (newCol <= 104)){
                        char newColchar = (char)(newCol + '0');
                        //String newLoc = newCol + newRow;
                        String newLoc = String.valueOf(newCol) + String.valueOf(newRow);

                        if (b.getPiece(newLoc) == null) {
                            possibleMoves.add(newLoc);
                        } else if (b.getPiece(newLoc).pieceColor == b.getPiece(loc).pieceColor) {
                            break;
                        } else {
                            possibleMoves.add(newLoc);
                            break;
                        }
                    }
                    break;
                }
            }
            break;
        }

        */



//e.g., a king at loc f5 can go to
//f6, f4, e6, e4, g6, g4, e5, g5
//e: 4, 5, 6; g: 4, 5, 6; f: 4, 6

        /*king can go in x, y (up, right +)
        (-1, 1); (0, 1); (1, 1),
        (-1, 0); (1,0)
        (-1, -1); (0, -1); (1, -1)
        */

//offset x -1, 0, 1
//offset y -1, 0, 1
//b.getPiece(loc + offset)

/*

public Rook(Color c) {this.color = c;}

    public String toString() {
        if(this.color == b){return "br";}
        if(this.color == w){return "wr";}

	throw new UnsupportedOperationException();
    }

    public List<String> moves(Board b, String loc) {
        List<String> rookCanMove = new ArrayList<String>();
        char col = charAt(0);
        int row = charAt(1);

 */