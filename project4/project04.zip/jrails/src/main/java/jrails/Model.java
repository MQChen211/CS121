package jrails;
import java.io.*;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;
public class Model {

    public static final String Filename = "Model_ds.txt";
    private static int id = 0;

    private static File f = new File(Filename);;
    //create the database file if not exists
    //https://www.w3schools.com/java/java_files_create.asp

    private static BufferedWriter bufwriter;
    private static BufferedReader bufreader;
    private static FileReader flReader;
    private static FileWriter flWriter;


    //use static block, reason: https://www.baeldung.com/java-static
    static {
        try {
            if(f.exists()){
                f.createNewFile();
                // if it does not exist
                //if (f.createNewFile())
                System.out.println("File created");};

            //else{System.out.println("File already exists");}

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


    public StringBuilder returnFieldVal() {
        StringBuilder sfldVal = new StringBuilder();
        Field[] list_flds = this.getClass().getFields();
        for (Field fld : list_flds) {
            try {
                sfldVal.append(id);
                sfldVal.append(",");
                Annotation ifCol = fld.getAnnotation(Column.class);
                Class<?> ifType = fld.getType();
                if (ifCol != null) {
                    if (ifType == String.class || ifType == int.class || ifType == boolean.class) {
                        Object objVal = fld.get(this);
                        if (objVal != null) {
                            sfldVal.append(objVal);
                            sfldVal.append(",");
                            sfldVal.append("\n");
                        } else {
                            sfldVal.append("null");
                            sfldVal.append(",");
                            sfldVal.append("\n");
                            //https://blog.csdn.net/qq_22260641/article/details/88873683
                            // or sfldVal.append(System.getProperty("line.separator));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return sfldVal;
    }



    public void ifexists(boolean tofile) throws IOException {
        //boolean tofile = false;
        boolean rowexists = false;
        FileReader fReader;
        //BufferedReader sReader = new BufferedReader(FileReader fileReader = new FileReader(f));
        BufferedReader sReader = new BufferedReader(new FileReader(f));
        StringBuilder strbd = new StringBuilder();
        BufferedWriter writer = new BufferedWriter(new FileWriter(f));

        while(sReader.readLine() != null){
            //if a row is not null, get id
            String[] elements = sReader.readLine().split(",");
            //get the 1st elm, which is the id
            String temp_id = elements[0]; // Integer.parseInt?
            int tmp_id = Integer.parseInt(temp_id);
            if(tmp_id == this.id){
                if(tofile = false){
                    strbd.append(returnFieldVal());
                    rowexists = true;}
                else{
                    rowexists = true;
                }
            }
            else{
                // id not exists
                strbd.append(sReader.readLine());
                strbd.append("\n");
                rowexists = true;
            }
        }

        if(rowexists = true){
            //Bufferedwriter = new BufferedWriter(fReader = new FileWriter(f, true));
            writer.write(new String(strbd));
            writer.close();
        }
        else{
            throw new UnsupportedOperationException();
        }
    }

    public void save() {
        /* this is an instance of the current model */
        throw new UnsupportedOperationException();
    }

    //reflection: https://www.cnblogs.com/tech-bird/p/3525336.html
//    public void save() throws IOException {
//        if (id == 0) {
//
//            try {
//                BufferedReader reader = new BufferedReader(new FileReader(f));
//                StringBuilder sb = null;
//                sb.append(returnFieldVal());
//                id = Integer.parseInt(UUID.randomUUID().toString().replace("-", ""));
//                BufferedWriter writer = new BufferedWriter(new FileWriter(f, true));
//                writer.write(new String(sb));
//                writer.close();
//            } catch (NumberFormatException e) {
//                throw new RuntimeException(e);
//            } catch (IOException e) {
//                throw new RuntimeException(e);
//            }
//        }
//
//        else{
//            ifexists(false);
//        }
//
//        /* this is an instance of the current model */
//        //throw new UnsupportedOperationException();
//    }


    public int id() {
        return this.id;
        //throw new UnsupportedOperationException();
    }
    public static <T> T find(Class<T> c, int id) {
        throw new UnsupportedOperationException();
    }

/*

    public static <T> T find(Class<T> c, int id) throws IOException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        BufferedReader fReader = new BufferedReader(new FileReader(f));
        while(fReader.readLine() != null){
            String[] elements = fReader.readLine().split(",");
            //get the 1st elm, which is the id
            String temp_id = elements[0];
            String temp_cname = elements[1];
            //if((temp_id == this.id &&) && (temp_cname == c.getSimpleName())){
            // materializes the row by creating a fresh instance of the model and initializing its fields
            if(Integer.parseInt(temp_id) == id) {
                Constructor ctor = c.getConstructor();
                Object obj = ctor.newInstance();
                Field[] flds = c.getFields();
                int lenField = flds.length;
                for(int i = 0; i <= lenField - 1; i++){
                    //for (Field f : flds) {
                    Annotation ano = flds[i].getAnnotation(Column.class);
                    Class<?> ifType = flds[i].getType();
                    if (ano != null) {
                        //if (ifType == String.class || ifType == int.class || ifType == boolean.class) {
                        if (ifType == String.class) {
                            if(elements[i] != "null") {
                                flds[i].set(obj, elements[i]);
                                // set the value of the field
                            }
                            else{flds[i].set(obj, "null");};
                        }
                        else if (ifType == int.class) {
                            flds[i].set(obj, Integer.parseInt(elements[i]));
                            //set the value of the field
                        }
                        else if(ifType == boolean.class){
                            flds[i].set(obj, Boolean.parseBoolean(elements[i]));
                        }
                        else{
                            throw new UnsupportedOperationException();
                        }
                    }//end ifCol: check column class
                }// end of for
                return (T) obj;
            }
            else {return null;}
            //  If there is no db entry with the given id, then find returns null
        }//end while
        fReader.close();
        //throw new UnsupportedOperationException();
        return null;
    }
    */

    public static <T> List<T> all(Class<T> c) {
        // Returns a List<element type>
        throw new UnsupportedOperationException();
    }

    public void destroy() {
        throw new UnsupportedOperationException();
    }


    public static void reset() {
        try{
            if(!f.exists()){
                f.createNewFile();
            }
            BufferedWriter wt = new BufferedWriter(new FileWriter(Filename));
            wt.write("");
            wt.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        //catch (FileNotFoundException e){
        //    e.printStackTrace();
        //}
    }

    //public static void reset() {
        //throw new UnsupportedOperationException();
    //}
}
