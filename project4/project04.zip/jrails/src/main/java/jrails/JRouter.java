package jrails;

import java.util.*;
import java.lang.reflect.Method;

public class JRouter {
    Set<Route> RouteSet = new HashSet<>();
    public class Route {
        public String verb;
        public String path;
        public Class clazz;
        public String method;

        //public String request = vert.concat(path);
        public Route(String vb, String pt, Class c, String mtd) {
            this.verb = verb;
            this.path = path;
            this.clazz = clazz;
            this.method = method;
            //this.request = rqst;
        }
    }



        public void addRoute(String verb, String path, Class clazz, String method) {
            Route rt = new Route(verb, path, clazz, method);
            RouteSet.add(rt);

        }

//        public void addRoute(String verb, String path, Class clazz, String method) {
//            // Implement me!
//        }

        // Returns "clazz#method" corresponding to verb+URN
        // Null if no such route

        public String getRoute(String verb, String path) {
            for (Route rt : RouteSet) {

                if ((rt.path == path) && (rt.verb == verb)) {
                    try {
                        String srt1 = rt.clazz.getSimpleName().concat("#");
                        String srt2 = rt.method;
                        String sRt = srt1.concat(srt2);
                        return sRt;
                    }
                    catch (Exception e){throw new RuntimeException();}
                }
            }
            return null;

        }

//        public String getRoute(String verb, String path) {
//            throw new UnsupportedOperationException();
//        }

        // Call the appropriate controller method and
        // return the result
//        public Html route(String verb, String path, Map<String, String> params) {
//            throw new UnsupportedOperationException();
//        }


    public Html route(String verb, String path, Map<String, String> params) {

        try {

            String rtName = getRoute(verb,path);
            if(rtName != null){



                String [] subName = rtName.split("#");
                String cName = subName[0];
                String mName = subName[1];


                Class rc = Class.forName(cName);
                Method rm = rc.getMethod(mName, Map.class);
                Html html = (Html) rm.invoke(null, params);
                return html;

            }

        }catch (Exception e){throw new RuntimeException();}

      //  else{throw new UnsupportedOperationException();}
        return null;
    }
}











/*
public class JRouter {
    public class Route {
        public String verb;
        public String path;
        public Class clazz;
        public String method;

        //public String request = vert.concat(path);
        public Route(String vb, String pt, Class c, String mtd) {
            this.verb = verb;
            this.path = path;
            this.clazz = clazz;
            this.method = method;
            //this.request = rqst;
        }
    }

    //HashMap<String, Route> RouterMap = new HashMap<>();
    Set<Route> RouteSet = new HashSet<>();

    public void addRoute(String verb, String path, Class clazz, String method) {
        Route rt = new Route(verb, path, clazz, method);
        RouteSet.add(rt);

    }
//        String request = verb.concat(path);
//        String vb = verb;
//        String pt = path;
//        Class c = clazz;
//        String mtd = method;
//        String request = verb.concat(path);
//        Route Rt = new Route(verb, path, clazz, method);
//        RouterMap.put(request, Rt);
    // Implement me!

    // Returns "clazz#method" corresponding to verb+URN
    // Null if no such route
    public String getRoute(String verb, String path) {
        for (Route rt : RouteSet) {
            if ((rt.path == path) && (rt.verb == verb)) {
                String srt1 = rt.clazz.getSimpleName().concat("#");
                String srt2 = rt.method;
                String sRt = srt1.concat(srt2);
                return sRt;

            }
        }
        return null;

    }

//        String request = verb.concat(path);
//        Set<String> rtKeySet = RouterMap.keySet();
//        for(String str: rtKeySet){
//            if(str == request){
//                String str1 = RouterMap.get(str).clazz.getSimpleName();
//                String str2 = RouterMap.get(str).method;
//                String str3 = str1.concat("#");
//                String strRoute = str3.concat(str2);
//                //RouterMap.get(str).clazz.getName() +"#"+ RouterMap.get(str).method;
//                return strRoute;
//            }
//
//        }
//        return null;
    //throw new UnsupportedOperationException();


    // Call the appropriate controller method and
    // return the result
    public Html route(String verb, String path, Map<String, String> params) throws InvocationTargetException, IllegalAccessException, InstantiationException, NoSuchMethodException, ClassNotFoundException {
        String rtName = getRoute(verb,path);
        if(rtName != null){

            String [] subName = rtName.split("#");
            String cName = subName[0];
            String mName = subName[1];

            Class rc = Class.forName(cName);
            Method rm = rc.getMethod(mName, Map.class);
            Html html = (Html) rm.invoke(null, params);
            return html;
        }
        else{throw new UnsupportedOperationException();}
    }
}


*/
//        String htrequest = verb.concat(path);
//        Set<String> hrtKeySet = RouterMap.keySet();
//        Class clazz = RouterMap.get(htrequest).clazz;
//        //List<String> htrtKeySet = (List<String>) RouterMap.keySet();
//        for(String str: hrtKeySet){
//            if(str == htrequest){
//                Class c = RouterMap.get(str).clazz;
//                String rm = RouterMap.get(str).method;
//                Method m = clazz.getMethod(rm, Map.class);
//                //Object obj = null;
//                //m.invoke(obj, params);
//                return (Html) m.invoke(null, params);
//            }
//
//        }
//        throw new UnsupportedOperationException();
//    }



