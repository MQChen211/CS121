
package jrails;

public class Html {

        private String str_Html;
        //public String toString() {
        //  return this.str_Html;
        //}

        public Html(){this.str_Html = "";}
        public Html(String str_Html){this.str_Html = str_Html;}

        public String toString() {
            return str_Html;
        }

        // define a method to make a html with tag

//      public String makeHtml(tag, hchild){
//          Html html = new Html();
//          html.str_Html = "<" + tag + ">" + hchild.str_Html + "<" + "/" + tag + ">";
//          //html.str_Html = "<tag>" + hchild.str + "/tag";
//          return html;
//      }



        public Html seq(Html h) {
            Html html = new Html();
            html.str_Html = this.str_Html + h.str_Html;
            return html;
        }

        public Html br() {
            Html html = new Html();
            html.str_Html = "<br/>";
            return html;
        }

        public Html t(Object o) {
            Html html = new Html();
            html.str_Html = o.toString();
            return html;
            // Use o.toString() to get the text for this
        }

        public Html p(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<p>" + child.str_Html + "</p>";
            return html;
            //return new Html(str_Html + "<p>" + child.str_Html + "</p>");
            //makeHtml("p", child);
        }

        public Html div(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<div>" + child.str_Html + "</div>";
            return html;
            //return new Html(str_Html + "<div>" + child.str_Html + "</div>");
            //makeHtml("div", child);
        }

        public Html strong(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<strong>" + child.str_Html + "</strong>";
            return html;
            //makeHtml("strong", child);
        }

        public Html h1(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<h1>" + child.str_Html + "</h1>";
            return html;
            //return new Html(str_Html + "<h1>" + child.str_Html + "</h1>");
            //makeHtml("h1", child);
        }

        public Html tr(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<tr>" + child.str_Html + "</tr>";
            return html;
            //return new Html(str_Html + "<tr>" + child.str_Html + "</tr>");
            //makeHtml("tr", child);
        }

        public Html th(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<th>" + child.str_Html + "</th>";
            return html;
            //return new Html(str_Html + "<th>" + child.str_Html + "</th>");
            //makeHtml("th", child);
        }

        public Html td(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<td>" + child.str_Html + "</td>";
            return html;
            //return new Html(str_Html + "<td>" + child.str_Html + "</td>");
            //makeHtml("td", child);
        }

        public Html table(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<table>" + child.str_Html + "</table>";
            return html;
            //return new Html(str_Html + "<table>" + child.str_Html + "</table>");
            //makeHtml("table", child);
        }

        public Html thead(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<thead>" + child.str_Html + "</thead>";
            return html;
            //return new Html(str_Html + "<thead>" + child.str_Html + "</thead>");
            //makeHtml("thead", child);
        }

        public Html tbody(Html child) {
            Html html = new Html();
            html.str_Html = str_Html + "<tbody>" + child.str_Html + "</tbody>";
            return html;
            //return new Html(str_Html + "<tbody>" + child.str_Html + "</tbody>");
            //makeHtml("tbody", child);
        }

        public Html textarea(String name, Html child) {
            Html html = new Html();
            html.str_Html = "<textarea name=\"" + name + "\">" + child.str_Html + "</textarea>";
            return html;
        }

        public Html link_to(String text, String url) {
            // form: <a href="/show?id=42">Show</a>
            Html html = new Html();
            html.str_Html = "<a href=\"" + url + "\">" + text + "</a>";
            return html;


        }

        public Html form(String action, Html child) {
            // form: "/create" accept-charset="UTF-8" method="post">HTML</form>
            Html html = new Html();
            html.str_Html = "<form action=\"" + action + "\" accept-charset=\"UTF-8\" method=\"post\">" + child.str_Html + "</form>";
            return html;
        }

        public Html submit(String value) {
            // form: <input type="submit" value="Save"/>
            Html html = new Html();
            html.str_Html = "<input type=\"submit\" value=\"" + value + "\"/>";
            return html;
        }


    }






