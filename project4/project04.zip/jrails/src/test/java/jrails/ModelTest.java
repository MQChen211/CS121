package jrails;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.core.IsNull.notNullValue;
import static org.junit.Assert.assertThat;

public class ModelTest {

    private Model model;

    @Before
    public void setUp() throws Exception {
        model = new Model(){};
    }

    @Test
    public void id() {
        assertThat(model.id(), notNullValue());
    }

    @Test
    public void Test() {
//
//
//        Book book1 = new Book();
//        book1.title = "This is Project 04";
//        book1.author = "A";
//        book1.num_copies = 11;
//        book1.save();
//        assertThat(Model.find(Book.class, 1).title, is(equalTo("It's a book.")));
//        assertThat(Model.find(Book.class, 1).author, is(equalTo("COMP 121")));
//        assertThat(Model.find(Book.class, 1).num_copies, is(equalTo(11)));
//
//
//        List<Book> lstBook = Model.all(Book.class); // returns all books in the db
//        for (Book book : lstBook) {
//            System.out.println(book.title);
//            System.out.println(book.author);
//            System.out.println(book.num_copies);
//        }
    }



    @After
    public void tearDown() throws Exception {
    }
}