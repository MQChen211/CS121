public class BadPath extends RuntimeException {
}