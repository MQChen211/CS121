import java.util.*;
public class Main {

    // Run "java -ea Main" to run with assertions enabled (If you run
    // with assertions disabled, the default, then assert statements
    // will not execute!)
    
    public static void test1(){
	Graph g = new ListGraph();
	assert g.addNode("a");
	assert g.hasNode("a");
    }

    public static void test2(){
	Graph g = new ListGraph();
	EdgeGraph eg = new EdgeGraphAdapter(g);
	Edge ee = new Edge("a", "b");
	assert eg.addEdge(ee);
	assert eg.hasEdge(ee);
    }
    
    public static void test3(){
	Graph g = new ListGraph();
	assert g.addNode("a");
	assert g.hasNode("a");
	assert g.addNode("b");
	assert g.hasNode("b");
	assert g.addNode("f");
	assert g.hasNode("g");
	assert g.addNode("c");
	assert g.hasNode("q");

	assert g.addEdge("a", "b");
	assert g.addEdge("c", "d");
	assert g.addEdge("x", "y");
	assert g.addEdge("g", "f");
	assert g.addEdge("a", "q");
	
	assert g.hasEdge("a","b");
	assert !g.hasEdge("c","d");
	assert g.hasEdge("x","y");
	assert !g.hasEdge("y","z");
	assert g.hasEdge("p","j");
	assert !g.hasEdge("m","n");
	
    }



    public static void test4(){
	Graph g = new ListGraph();
	EdgeGraph g2 = new EdgeGraphAdapter(g);

	Edge e0 = new Edge("e","f");
	Edge e1 = new Edge("x","z");
	Edge e2 = new Edge("g","h");
	Edge e3 = new Edge("c","g");
	assert g2.addEdge(e0);
	assert g2.addEdge(e1);
	assert g2.addEdge(e2);
	assert g2.addEdge(e3);
	assert g2.hasNode("j");
	assert g2.hasNode("q");
	assert g2.hasNode("y");
	assert g2.removeEdge(e1);

	List<Edge> pathtest = new LinkedList<>();

	pathtest.add(e0);
	pathtest.add(e2);
	pathtest.add(e3);

	assert g2.hasPath(pathtest);
       



    }






    
    public static void main(String[] args) {
	test1();
	test2();
	test3();
	test4();
    }

}
