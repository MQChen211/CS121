import java.util.*;

public class ListGraph implements Graph {
	private HashMap<String, LinkedList<String>> nodes = new HashMap<>();

	public boolean addNode(String n) {
		//if (!this.hasNode(n))
		if (!nodes.containsKey(n)) {
			nodes.put(n, new LinkedList<String>());
			return true;
		}
		return false;
		//throw new UnsupportedOperationException();
	}


	public boolean addEdge(String n1, String n2) {

		if (!nodes.containsKey(n1) || !nodes.containsKey(n2)) {
			throw new NoSuchElementException();
		}
		if (!nodes.get(n1).contains(n2)) {
			nodes.get(n1).add(n2);
			return true;
		}
		return false;
		//throw new UnsupportedOperationException();
	}


	public boolean hasNode(String n) {

		return nodes.containsKey(n);

		//throw new UnsupportedOperationException();
	}


	public boolean hasEdge(String n1, String n2) {
		if ((!nodes.containsKey(n1)) || (!nodes.containsKey(n2))) {
			return false;
		}

		for (String s : nodes.get(n1)) {
			if (s.equals(n2)) return true;
		}
		return false;
	/*
	for(String s: nodes.keySet()){
	    if(s.equals(n1) && nodes.get(s).containsValue(n2)){
	       return true;
	    }
	}
	*/
		//throw new UnsupportedOperationException();
	}


	public boolean removeNode(String n) {
		if (!nodes.containsKey(n)) {
			return false;
		}
		nodes.remove(n);//remove n also removes its succ

		for(String ss: nodes.keySet()){
			if(nodes.get(ss).contains(n)){

				nodes.remove(ss);
			}
		}//remove pred of n
		//nodes.remove(succ(n));
		//nodes.remove(pred(n));
		return true;
		//throw new UnsupportedOperationException();
	}



	public boolean removeEdge(String n1, String n2) {

		for (String s : nodes.keySet()) {
			//if (s.equals(n1)) {
				//for (String ss : nodes.get(n1)) {
					if (s.equals(n1)) {
						for(String ss: nodes.get(n1)){
							nodes.remove(s);
							nodes.remove(ss);
							return true;
						}


					}
				//}
			//}
		}

		if (!nodes.containsKey(n1) || !nodes.containsKey(n2)) {
			throw new NoSuchElementException();
		}

		return false;
	}
		/*
		if(nodes.containsKey(n1)) {
			for (String s1 : nodes.get(n1)) {
				if (s1.equals(n2)){
					nodes.removeNode(n1);
					nodes.removeNode(n2);
					return true;
				}
			}
		}

		if(nodes.containsKey(n2)) {
			for (String s2 : nodes.get(n2)) {
				if (s2.equals(n1)){
					nodes.removeNode(n1);
					nodes.removeNode(n2);
					return true;
				}
			}
		}

		if (!nodes.containsKey(n1) || !nodes.containsKey(n2)) {
			throw new NoSuchElementException();
		}

		return false;
		*/










	public List<String> nodes() {
		LinkedList<String> lstallnodes = new LinkedList<String>();
		lstallnodes.addAll(nodes.keySet());
		return lstallnodes;
		//List<String> listAll = new ArrayList<String>();
		//throw new UnsupportedOperationException();
	}


	public List<String> succ(String n) {
		if (!this.hasNode(n)) {
			throw new NoSuchElementException();
		}
		LinkedList<String> nsucc = new LinkedList<String>();
		for (String s : nodes.get(n)) {
			nsucc.add(s);
		}
		return nsucc;
		//throw new UnsupportedOperationException();
	}

	public List<String> pred(String n) {
		if (!this.hasNode(n)) {
			throw new NoSuchElementException();
		}
		LinkedList<String> npred = new LinkedList<String>();
		for (String p : nodes.keySet()) {
			if (nodes.get(p).contains(n)) {
				npred.add(n);
			}
		}
		return npred;
		//throw new UnsupportedOperationException();
	}


	public Graph union(Graph g) {

		Graph gUnion = new ListGraph();
		for(String s: nodes.keySet()){
			gUnion.addNode(s);
			for(String ss: nodes.get(s)){
				if(!gUnion.hasNode(ss)){
					gUnion.addNode(ss);
				}
				gUnion.addEdge(s,ss);
				//there always are edges between s and succ(s)
			}
		}

		for(String i:g.nodes()){
			if(!this.hasNode(i)){
				gUnion.addNode(i);
			}
			for(String ii:g.succ(i)){
				if(!this.hasNode(ii)){
					gUnion.addNode(ii);
				}
				gUnion.addEdge(i,ii);
				//there always are edges between i and g.succ(i)
			}
		}
		//err: nodes.succ(j), this.succ(j), nodes.hasNode()
		return gUnion;
		//throw new UnsupportedOperationException();
	}


	//nodes: nodes of new graph, this.nodes:private
	public Graph subGraph(Set<String> nodes) {
		Graph gsub = new ListGraph();
		for (String s : nodes) {
			if (this.hasNode(s)) {
				gsub.addNode(s);
				//if the original graph and given graph have
				//node in common, then gsub.addNode()

				// err: s.succ, nodes.succ
				for (String s2 : this.succ(s)) {
					if (nodes.contains(s2)) {
						gsub.addNode(s2);
						gsub.addEdge(s, s2);
					}
				}

				/*
				for (String s3 : s.pred()) {
					if (this.hasNode(s3)) {
						gsub.addNode(s3);
						gsub.addEdge(s, s3);
					}
				}
				*/
			}


		}

		return gsub;
		//throw new UnsupportedOperationException();
	}


	//This code is edit based on the youtube tutorial
	//https://www.youtube.com/watch?v=X6RkyPFE6wg&list=LL&index=2&t=542s
	//check if n1's succ contains n2
	//record lenth of path in a hashset as counts
	public boolean connected(String n1, String n2) {
		HashSet<String> hasVisited = new HashSet<>();
		Queue<String> toVisit = new LinkedList<>();
		toVisit.add(n1);

		if (!this.hasNode(n1) || !this.hasNode(n2)) {
			throw new NoSuchElementException();
		}
		if (n1.equals(n2)) {
			return true;
		}
		if (this.hasEdge(n1, n2)) {
			return true;
		}

		while(toVisit.size() > 0) {
			String currentNode = toVisit.poll();
			hasVisited.add(currentNode);

			for (String nextNode : this.succ(currentNode)) {
				if (!hasVisited.contains(nextNode)) {
					if (nextNode.equals(n2)) {
						return true;
					}
				}

				toVisit.add(nextNode);

			}
		}
		return false;
		//return dfsCheck(n1, n2, visitednodes);
		//throw new UnsupportedOperationException();
	}


//I wrote connected method based on the tutorial youtube https://www.youtube.com/watch?v=X6RkyPFE6wg&list=LL&index=2&t=578s
//I tried to write a method to check connection by dfs, but it didn't work out
    /*

	public boolean connected(String n1, String n2) {

	HashSet<String> lenCounts= new HashSet<>();
	lenCounts.add(n1);
		private boolean dfsCheck(String n1, String n2, lenCounts) {
			for(String x: this.succ(n1)){
				if (!lenCounts.contains(x)){
					lenCounts.add(x);
					return true;
				}
			}
			return false;
		}
`	*/

}

/*
I haven't use Java before so I have to check a lot of tutorial and codes, I have listed the reference
that I have read.

Reference:
https://www.youtube.com/watch?v=X6RkyPFE6wg&list=LL&index=2&t=542s
https://www.youtube.com/watch?v=PApEamXn94I
https://www.youtube.com/watch?v=QBfO4_C0Emk
https://github.com/gabriellebeaudry/comp410_datastructures_java/tree/master/Assignment1/src/LinkedList_A1
https://www.cpp.edu/~ftang/courses/CS241/notes/graph.htm
https://gist.github.com/toneeraj/4418977
https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/
https://www.baeldung.com/java-hashmap
https://www.softwaretestinghelp.com/java-graph-tutorial/
https://www.callicoder.com/java-hashmap/
https://courses.cs.duke.edu/cps100e/fall10/class/11_Bacon/code/Graph.html
https://cs.smu.ca/~porter/csc/341/code/examples/zyBookJava/Graphs/FlightsGraphDemo/Graph.java2html#Graph
https://gist.github.com/jedavidson/1411610bafab5192bb36104c4bf9f945
https://www.programcreek.com/java-api-examples/?CodeExample=add+edge+graph
https://gist.github.com/thmain/9b16692c04884461cb78b8cef019be3f
https://blog.csdn.net/weixin_43912853/article/details/118680297
https://github.com/VamsiSangam/theoryofprogramming/blob/master/Graph%20Theory/Adjcacency%20List/Java/AdjacencyList.java
https://www.lavivienpost.net/weighted-graph-as-adjacency-list/
https://algorithms.tutorialhorizon.com/given-graph-remove-a-vertex-and-all-edges-connect-to-the-vertex/
https://courses.cs.washington.edu/courses/cse373/11wi/lectures/02-25/programs/Graph.java



 */