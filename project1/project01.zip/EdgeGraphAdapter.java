import java.util.*;

public class EdgeGraphAdapter implements EdgeGraph {

    private Graph g;

    public EdgeGraphAdapter(Graph g) { this.g = g; }

    public boolean addEdge(Edge e) {

		String ns = e.getSrc();
		String nd = e.getDst();

		if(g.hasEdge(ns, nd)){
			return false;}
		else{
			g.addNode(ns);
			g.addNode(nd);
			g.addEdge(ns,nd);
		}
		return true;
	//throw new UnsupportedOperationException();
    }

    

    public boolean hasNode(String n) {
		if(g.hasNode(n)){

			return true;
		}
		return false;
		//throw new UnsupportedOperationException();
    }



    public boolean hasEdge(Edge e) {
			String ns = e.getSrc();
			String nd = e.getDst();
			if(g.hasEdge(ns, nd)){
				return true;
			}
			return false;
	//throw new UnsupportedOperationException();
    }

    

    public boolean removeEdge(Edge e) {
    	String ns = e.getSrc();
		String nd = e.getDst();
		if(g.hasEdge(ns, nd)){

			g.removeNode(ns);
			g.removeNode(nd);
			//g.removeEdge(ns, nd);
			return true;
		}

		if(g.hasEdge(nd, ns)){
			g.removeNode(ns);
			g.removeNode(nd);
			//g.removeEdge(nd, ns);
			return true;

		}
		return false;
	
	//throw new UnsupportedOperationException();
    }


    

    public List<Edge> outEdges(String n) {
		List<Edge> nstart = new LinkedList<>(); //list of nodes that start from n
		//check g's succ
		for(String s: g.succ(n)){
			Edge startfrom = new Edge(n, s);
			nstart.add(startfrom);

		}
		return nstart;
		//throw new UnsupportedOperationException();
    }
    //returns a list of all edges that start at node n


    

    public List<Edge> inEdges(String n) {
    	List<Edge> nend = new LinkedList<>(); //list of nodes end to n
    	//check g's pred
		for(String s: g.pred(n)){
			Edge endto = new Edge(s, n);
			nend.add(endto);

		}
		return nend;
	//throw new UnsupportedOperationException();
    }


    

    public List<Edge> edges() {
		List<Edge> alledges = new LinkedList<>();
		for(String s: g.nodes()){
			alledges.addAll(inEdges(s));
			alledges.addAll(outEdges(s));
		}
		return alledges;

	//throw new UnsupportedOperationException();
    }

  

    public EdgeGraph union(EdgeGraph g) {

    	//don't understand why this not working
		for(Edge edge: g.edges()){
			if(!this.hasEdge(edge)){
			this.addEdge(edge);
			}
		}
		return this;


		/*
		for(Edge edge: this.edges()){
			if(!g.hasEdge(edge)){
				g.addEdge(edge);
			}
		}
		return g;
		*/


	//throw new UnsupportedOperationException();
    }


    
    

    public boolean hasPath(List<Edge> e) {
		//e is a path contains edges e1, e2, ...,en
		if(e.isEmpty()){return true;}
		int L = e.size()-1;
		for(int i = 0; i<L;i++){
			//check if the argument is a path
			if(!(e.get(i).getDst().equals(e.get(i+1).getSrc()))){
				throw new BadPath();
			}

			if(this.hasEdge(e.get(i))){
			return true;
			}//if l = e0, e1, ... ei is in the graph
			return false;


		}
		return true;
	//check if ei.getDst()==e(i+1).getSrc()
	//throw new UnsupportedOperationException();
    }

}
