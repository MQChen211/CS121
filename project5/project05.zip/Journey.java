import java.lang.reflect.Array;
import java.util.*;
public class Journey {
    public Passenger p_Passenger;
    public Station s_Station;
    public ArrayList<Station> lst_Station = new ArrayList<>();

    public void setP_Passenger(String name){
        this.p_Passenger = Passenger.make(name);
    }

    public void setLst_Station(List<String> stations){
        for(String stn: stations){
            this.s_Station = Station.make(stn);
            this.lst_Station.add(this.s_Station);
        }
        Station curStation = lst_Station.get(0);
        Station nxtStation = lst_Station.get(1);
        this.p_Passenger.station_cur = curStation;
        this.p_Passenger.station_nxt = nxtStation;
        this.p_Passenger.p_On_Train = null; // passengers on train
        this.p_Passenger.pOnTrain_Status = false; // passenger status, false: not on the train; true: on the train

    }

}


// Add a new passenger journey to the simulation, where name is the name of the passenger and stations is an ordered
// list of stations the passenger wants to visit.

/*
    public Train t_Train;
    public Station s_Station;
    public ArrayList<Station> lst_Station = new ArrayList<>();

    public void setT_Train(String name, List<String> stations){
        this.t_Train = Train.make(name);
        Station cur_Station = Station.make(stations.get(0));
        Station nxt_Station = Station.make(stations.get(1));
        this.t_Train.station_cur = cur_Station;
        this.t_Train.station_nxt = nxt_Station;
        this.t_Train.direction = 1;
        this.t_Train.inDirection = true;
        this.t_Train.reDirection = false;
    }

    public void setLst_Station(List<String> stations){
        for(String stn: stations){
            this.s_Station = Station.make(stn);
            this.lst_Station.add(s_Station);
        }
    }
 */