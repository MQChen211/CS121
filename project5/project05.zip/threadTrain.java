import java.lang.*;

public class threadTrain{
    private final whenTostop whenTostop;
    private Log log;
    private Train t;
    private MBTA mbta;

    public threadTrain(Log log, MBTA mbta, Train t, whenTostop sig) {
            this.log = log;
            this.mbta = mbta;
            this.t = t;
            this.whenTostop = sig;
    }

        public void processTrain(){
            while (true){
                Station tcur = t.station_cur;
                Station tnxt = t.station_nxt;

                synchronized (tcur) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }

                    synchronized (tnxt) {
                        if (t.station_nxt.isNoTrain_inStation == false) {
                            try {
                                t.station_nxt.wait();
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                    t.station_nxt.isNoTrain_inStation = false;
                    t.station_cur.isNoTrain_inStation = true;
                    log.train_moves(t, t.station_cur, t.station_nxt);
                    t.station_cur.notify();
                    t.station_cur = t.station_nxt;
                }

                if(this.whenTostop.sig_stop == false){break;}
            }

        }
    }



