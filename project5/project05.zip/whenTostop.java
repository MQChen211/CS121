import static java.lang.Thread.sleep;

public class whenTostop{
      MBTA mbta_trd = new MBTA();
      public volatile boolean sig_stop = false;

      public void process(){
        while(true){
          try {
            sleep(500);
          } catch (InterruptedException e) {
            throw new RuntimeException(e);
          }
          if(mbta_trd.p_Lst_Journey_finished.size() == mbta_trd.pJourneyMap.size()){
            sig_stop = true;
            break;
          }
        }
      }

}
