import java.util.*;
//Add a new train line to the simulation, where name is the name of the line and stations is an ordered list of stations on the line.
public class Line {
    public Train t_Train;
    public Station s_Station;

    public Passenger p_Passenger;
    public ArrayList<Station> lst_Station = new ArrayList<>();

    public ArrayList<Passenger> lst_Passenger = new ArrayList<>();

    public void setT_Train(String name, List<String> stations){
        this.t_Train = Train.make(name);
        Station cur_Station = Station.make(stations.get(0));
        Station nxt_Station = Station.make(stations.get(1));
        this.t_Train.station_cur = cur_Station;
        this.t_Train.station_nxt = nxt_Station;
        this.t_Train.direction = 1;
        this.t_Train.inDirection = true;
        this.t_Train.reDirection = false;
    }

    public void setLst_Station(List<String> stations){
        for(String stn: stations){
            this.s_Station = Station.make(stn);
            this.lst_Station.add(this.s_Station);
        }
    }

    public void setLst_Passenger(List<String> passengers){
        for(String psg: passengers){
            this.p_Passenger = Passenger.make(psg);
            this.lst_Passenger.add(this.p_Passenger);
        }
    }

}
