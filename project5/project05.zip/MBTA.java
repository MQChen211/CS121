import java.util.*;
import java.io.*;
import com.google.gson.Gson;
public class MBTA {

  public List<Passenger> p_Lst_Journey_finished = new ArrayList<>();  // passengers not on the train
  //public List<Passenger> getPassenger_Lst_onTrain = new ArrayList<>(); // passengers on the train
  public Set<Line> tLineSet = new HashSet<>(); // a set of lines
  public Set<Journey> pJourneySet = new HashSet<>(); // a set of passengers' journeys
  public HashMap<Passenger, Journey> pJourneyMap = new HashMap<>(); // map of passenger and his/her journey
  //public HashMap<String , Journey> pJourneyMap2= new HashMap<>(); // map of passenger name and journey

  //public HashMap<String, Line> lineHashMap = new HashMap<>();
  // lineHashMap: String train name, Line train line

  // Creates an initially empty simulation
  public MBTA() {
    Passenger.lst_passenger.clear();
    Station.lst_station.clear();
    Train.lst_train.clear();
  }

  // Adds a new transit line with given name and stations
  public void addLine(String name, List<String> stations) {
    Line line = new Line();
    line.setT_Train(name, stations);
    line.setLst_Station(stations);
    tLineSet.add(line);
    //lineHashMap.put(name, line);

    //throw new UnsupportedOperationException();
  }

  // Adds a new planned journey to the simulation
  public void addJourney(String name, List<String> stations) {
    Journey journey = new Journey();
    journey.setLst_Station(stations);
    journey.setP_Passenger(name);
    pJourneySet.add(journey);
    pJourneyMap.put(Passenger.make(name), journey);
    //pJourneyMap2.put(name, journey);

    //throw new UnsupportedOperationException();
  }

  // Return normally if initial simulation conditions are satisfied, otherwise
  // raises an exception
  // initial simulation condition:
  // 1. train is in the inOrder direction: inDirection = true; or reDirection = false; or direction == 1
  // 2. current station is the 1st station on list
  public void checkStart() {
    // class Line: t_Train, s_Station, lst_Station
    for(Line ln: tLineSet){
      if(ln.t_Train.inDirection != true){throw new UnsupportedOperationException();}  // check if in the inOrder direction
      if(ln.lst_Station.get(0) != ln.t_Train.station_cur){throw new UnsupportedOperationException();} // check if train's cur_station == 1st station
    }

    // class journey: p_Passenger, s_Station, lst_Station
    // station_cur should be stations.get(0)
    // station_nxt should be stations.get(1)
    // passenger status should be onTrain
    for(Journey jny: pJourneySet){
      if(jny.p_Passenger.station_cur != jny.lst_Station.get(0)){throw new UnsupportedOperationException();}
      if(jny.p_Passenger.station_nxt != jny.lst_Station.get(1)){throw new UnsupportedOperationException();}
      if(jny.p_Passenger.p_On_Train != null){throw new UnsupportedOperationException();}
      if(jny.p_Passenger.pOnTrain_Status != false){throw new UnsupportedOperationException();}

    }

  }

  // Return normally if final simulation conditions are satisfied, otherwise
  // raises an exception
  public void checkEnd() {
    for(Line ln: tLineSet){
      int lnSize = ln.lst_Station.size() - 1;
      if(ln.lst_Station.get(lnSize) != ln.t_Train.station_cur){throw new UnsupportedOperationException();} // check if train's cur_station == last station
    }
    // current station should be the last station on list


    // Passenger's current station should be the last station
    // Passenger's next station should be none
    // There should be no passengers on the train
    for(Journey jny: pJourneySet){
      int jnySize = pJourneySet.size() - 1;
      if(jny.p_Passenger.station_cur != jny.lst_Station.get(jnySize)){throw new UnsupportedOperationException();}
      if(jny.p_Passenger.station_nxt != null){throw new UnsupportedOperationException();}
      if(jny.p_Passenger.p_On_Train != null){throw new UnsupportedOperationException();}
      if(jny.p_Passenger.pOnTrain_Status != false){throw new UnsupportedOperationException();}
    }
  }

  // reset to an empty simulation
  public void reset() {
    for(Line ln: tLineSet){

      //reset t_Train
      ln.t_Train.station_cur = null;
      ln.t_Train.station_nxt = null;
      ln.t_Train.direction = 1;
      ln.t_Train.inDirection = true;
      ln.t_Train.reDirection = false;

      //reset lst_Station
      for(Station stn: ln.lst_Station){
        stn.isNoTrain_inStation = true;
        stn.isNoPassenger_inStation = true;
        stn.p_num_inStation = 0;
      }
    }
    tLineSet.clear();

    for(Journey jny: pJourneySet){
      jny.p_Passenger.station_cur = null;
      jny.p_Passenger.station_nxt = null;
      jny.p_Passenger.pOnTrain_Status = false;
      jny.p_Passenger.p_On_Train = null;
    }
    pJourneySet.clear();

    p_Lst_Journey_finished.clear();
    //throw new UnsupportedOperationException();
  }



  // return String
  public String JsonClass(String filename) {
    StringBuilder stringBuilder;
    try {
      FileReader fileReader = new FileReader(filename);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      stringBuilder = new StringBuilder();

      while (bufferedReader.readLine() != null) {
        String fileLine = bufferedReader.readLine();
        //fileLine.toString();
        stringBuilder.append(fileLine);
        stringBuilder.append("\n");
        System.out.println(stringBuilder);
      }
      bufferedReader.close();
      fileReader.close();
    } catch (Exception e) {
      throw new UnsupportedOperationException();
    }
    return stringBuilder.toString();
  }


  // https://www.geeksforgeeks.org/parse-json-java/
  // adds simulation configuration from a file
  // Load a JSON simulation configuration, adding the lines and journeys listed in the JSON file.

  /*
  public void loadConfig(String filename) {
    Gson gson = new Gson();
    File configFile = new File(filename);
    StringBuilder stringBuilder;
    try {
      FileReader fileReader = new FileReader(filename);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      stringBuilder = new StringBuilder();

      while (bufferedReader.readLine() != null) {
        String fileLine = bufferedReader.readLine();
        //fileLine.toString();
        stringBuilder.append(fileLine);
        String str = stringBuilder.toString();
        //stringBuilder.append("\n");
        System.out.println(stringBuilder);
        Cjson cj = gson.fromJson(str, Cjson.class);
        for(String nln: cj.lines.keySet()){
          this.addLine(nln, cj.lines.get(nln));
        }
        for(String ntrp: cj.lines.keySet()){
          this.addJourney(ntrp, cj.trips.get(ntrp));
        }
      }
      bufferedReader.close();
      fileReader.close();

    } catch (Exception e) {
      throw new UnsupportedOperationException();
    }
  }


  */


  public void loadConfig(String filename){
    Gson gson = new Gson();
    StringBuilder stringBuilder;
    File configFile = new File(filename);
    stringBuilder = new StringBuilder();
    try(FileReader fileReader = new FileReader(filename)){
      Cjson cj = gson.fromJson(fileReader, Cjson.class);
      for(Map.Entry<String, List> entry: cj.lines.entrySet()){
        List lnlst = entry.getValue();
        addLine(entry.getKey(), lnlst);
      }
      for(Map.Entry<String, List> entry: cj.trips.entrySet()){
        List tplst = entry.getValue();
        addLine(entry.getKey(), tplst);
      }
    }
    catch(Exception e){
      throw new UnsupportedOperationException();
    }
  }


  public class Cjson{
    public HashMap<String, List> lines;
    public HashMap<String, List> trips;

  }

}


//https://www.zhihu.com/question/371081743

// add configClass
//class configClass(String filename){
//  public String filename;
//  File configFile = new File(filename);
//  public HashMap<String, List> lines = new HashMap<>();
//  public HashMap<String, List> trips = new HashMap<>();
//
//   try {
//
//    FileReader fileReader = new FileReader(configFile);
//    BufferedReader bufferedReader = new BufferedReader(fileReader);
//    StringBuilder stringBuilder = new StringBuilder();
//
//    while(bufferedReader.readLine() != null){
//      //int readInt = bufferedReader.read();
//      //char appendChar = (char) readInt;
//      stringBuilder = bufferedReader.readLine();
//    }
//    fileReader.close();
//    bufferedReader.close();
//    stringBuilder.toString();
//
//
//  } catch (FileNotFoundException e) {
//    throw new RuntimeException(e);
//  }
//
//}




// https://www.javadoc.io/doc/com.google.code.gson/gson/latest/com.google.gson/com/google/gson/Gson.html
