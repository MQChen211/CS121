import java.util.*;

public class MoveEvent implements Event {
  public final Train t; public final Station s1, s2;
  public MoveEvent(Train t, Station s1, Station s2) {
    this.t = t; this.s1 = s1; this.s2 = s2;
  }
  public boolean equals(Object o) {
    if (o instanceof MoveEvent e) {
      return t.equals(e.t) && s1.equals(e.s1) && s2.equals(e.s2);
    }
    return false;
  }
  public int hashCode() {
    return Objects.hash(t, s1, s2);
  }
  public String toString() {
    return "Train " + t + " moves from " + s1 + " to " + s2;
  }
  public List<String> toStringList() {
    return List.of(t.toString(), s1.toString(), s2.toString());
  }



  // mbta.tLineSet
  // mbta.pJourneySet
  // Line.java: t.station_cur, t.station_nxt, t.direction, t.inDirection, t.reDirection
  // Journey.java: p.station_cur, p.station_nxt, p.p_Train, p.p_Status
  public void replayAndCheck(MBTA mbta) {
    for(Line ln: mbta.tLineSet){
      //if((this.t == ln.t_Train) && (this.t.station_cur == s1) && (this.t.station_nxt == s2)){
      if(this.t == ln.t_Train){
        if((this.t.station_cur == s1) && (this.t.station_nxt == s2)) {
          if (s2.isNoTrain_inStation == true) {
            // set current station to be the next station: s2
            // set s1 to be empty station, and s2 be not empty
            this.t.station_cur = s2;
            s1.isNoTrain_inStation = true;
            s2.isNoTrain_inStation = false;

            // set train direction
            // when reach the final station, reOrder, next station index -1
            // when at the initial station, inOrder, next station index +1
            int size_lst_station = ln.lst_Station.size() - 1;
            if (ln.lst_Station.indexOf(s2) == 0) {
              t.inDirection = true;
              t.direction = 1;
              int s2Inx = ln.lst_Station.indexOf(s2);
              t.station_nxt = ln.lst_Station.get(s2Inx + 1);
              return;
            }
            if (ln.lst_Station.indexOf(s2) == size_lst_station) {
              t.reDirection = true;
              t.direction = -1;
              int s2Inx = ln.lst_Station.indexOf(s2);
              t.station_nxt = ln.lst_Station.get(s2Inx - 1);
              return;
            }

          }
        }

      }

    }

    throw new UnsupportedOperationException();
  }
}
