import static org.junit.Assert.*;
import org.junit.*;
import java.util.*;
public class Tests {
  @Test public void testPass() {
    assertTrue("true should be true", true);
  }

  @Test
  public void test01() {
    MBTA m = new MBTA();
    List<String> stations = new ArrayList<>();
    stations.add("s1");
    stations.add("s2");
    stations.add("s3");
    stations.add("s4");

    MBTA mbta = new MBTA();
    mbta.addLine("red", stations);

    Train red = Train.make("red");

    Station s1 = Station.make("s1");
    Station s2 = Station.make("s2");
    Station s3 = Station.make("s3");
    Station s4 = Station.make("s4");

    Log log = new Log();
    log.train_moves(red, s1, s2);
    log.train_moves(red,s2, s3);
    log.train_moves(red, s3, s4);

  }


}
