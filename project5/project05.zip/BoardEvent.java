import java.util.*;

public class BoardEvent implements Event {
  public final Passenger p; public final Train t; public final Station s;
  public BoardEvent(Passenger p, Train t, Station s) {
    this.p = p; this.t = t; this.s = s;
  }
  public boolean equals(Object o) {
    if (o instanceof BoardEvent e) {
      return p.equals(e.p) && t.equals(e.t) && s.equals(e.s);
    }
    return false;
  }
  public int hashCode() {
    return Objects.hash(p, t, s);
  }
  public String toString() {
    return "Passenger " + p + " boards " + t + " at " + s;
  }
  public List<String> toStringList() {
    return List.of(p.toString(), t.toString(), s.toString());
  }


   // Passenger p boards t at s
   // check passesenger's journey
   // initially p not on train, pOnTrain_Status == false, the train that p is on should be null
   // if not arrived, move to the next station
   // in order to board p, only need to check if p has arrived at the last station
   // no need to consider train's direction

  public void replayAndCheck(MBTA mbta) {
    for(Journey jny: mbta.pJourneySet) {
      int jnySize = jny.lst_Station.size() - 1;
      if ((jny.p_Passenger == p) && (p.station_cur == s) && (p.pOnTrain_Status == false) && (p.p_On_Train == null)) {
        for (Line ln : mbta.tLineSet) {
          if ((ln.t_Train == t) && (t.station_cur == s)){

            if (jny.lst_Station.indexOf(s) < jnySize) {
              p.station_cur = p.station_nxt;
              int s2Inx = ln.lst_Station.indexOf(p.station_nxt);
              p.station_nxt = jny.lst_Station.get(s2Inx + 1);
            }
            else if (jny.lst_Station.indexOf(s) == jnySize) {
                p.station_nxt = null;
            }
            else{
              throw new UnsupportedOperationException();
            }
            p.p_On_Train = t;
            return;
          }


//            if (jny.lst_Station.indexOf(s) < jnySize) {
//              p.station_cur = p.station_nxt;
//              if (jny.lst_Station.indexOf(s) == jnySize) {
//                p.station_nxt = null;
//              } else {
//                int s2Inx = ln.lst_Station.indexOf(p.station_nxt);
//                p.station_nxt = jny.lst_Station.get(s2Inx + 1);
//              }
//              p.p_On_Train = t;
//              return;
//            }
          }
        }
      }
    }
  }

  /*
  public void replayAndCheck(MBTA mbta) {
    for(Journey jny: mbta.pJourneySet) {
      int jnySize = jny.lst_Station.size() - 1;
      if ((jny.p_Passenger == p) && (p.station_cur == s) && (p.pOnTrain_Status == false) && (p.p_On_Train == null)) {
        for (Line ln : mbta.tLineSet) {
          if ((ln.t_Train == t) && (t.station_cur == s)) {

            //inOrder
            if (jny.lst_Station.indexOf(s) < jnySize && (t.inDirection == true)) {
              p.station_cur = p.station_nxt;
              if (jny.lst_Station.indexOf(s) == jnySize) {
                p.station_nxt = null;
              } else {
                int s2Inx = ln.lst_Station.indexOf(p.station_nxt);
                p.station_nxt = jny.lst_Station.get(s2Inx + 1);
              }
            }

            //reOrder
            else if (jny.lst_Station.indexOf(s) > 0 && (t.inDirection == false)) {
              p.station_cur = p.station_nxt;
              if (jny.lst_Station.indexOf(s) == 0) {
                p.station_nxt = null;
              } else {
                int s2Inx = ln.lst_Station.indexOf(p.station_nxt);
                p.station_nxt = jny.lst_Station.get(s2Inx - 1);
              }
            }
            p.p_On_Train = t;
            return;
          }
        }
      }
    }
    throw new UnsupportedOperationException();
  }
  */







