import java.util.*;
public class Passenger extends Entity {
  private Log log;
  private Passenger(String name) { super(name); }
  public Station station_nxt;
  public volatile Station station_cur;
  public boolean pOnTrain_Status = false; // passenger status, false: not on the train; true: on the train
  public Train p_On_Train = null; //passenger is on train
  public static Map<String, Passenger> lst_passenger = new HashMap<>();


  public static Passenger make(String name) {
    if(!lst_passenger.containsKey(name)){
      Passenger newPassenger = new Passenger(name);
      lst_passenger.put(name, newPassenger);
    }
    Passenger p = lst_passenger.get(name);
    // Change this method!
    return p;
  }
}
