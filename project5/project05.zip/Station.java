import java.util.*;
public class Station extends Entity {
  private Log log;
  private Station(String name) { super(name); }
  public boolean isNoTrain_inStation = true; // no train in station
  //public boolean hasTrain_inStation = false;
  public boolean isNoPassenger_inStation = true; // no one in station
  public int p_num_inStation = 0; //number of passenger in station is 0
  //public Train pOnTrain = null;


  public static HashMap<String, Station> lst_station = new HashMap<>();


  public static Station make(String name) {
    if(!lst_station.containsKey(name)){
      Station newStation = new Station(name);
      lst_station.put(name, newStation);
    }

    Station s = lst_station.get(name);
    return s;
  }

//    if(stations.containsKey(name)){
//      return stations.get(name);
//    }
//    else{
//      stations.put(name, new Station(name));
//    }
//    // Change this method!
//
//    return stations.get(name);
//  }
}
