import java.util.*;
import java.util.HashMap;
import java.util.Map;
public class Train extends Entity {
  private static Log log;
  private Train(String name) { super(name); }
  public static HashMap<String, Train> lst_train = new HashMap<>();
  public volatile Station station_cur;

  public Station station_nxt;

  public boolean inDirection = true; //in order direction
  public boolean reDirection = false; //reverse order direction
  public int direction = 1;
  //control memory order


  public static Train make(String name) {
    if(!lst_train.containsKey(name)){
      Train t = new Train(name);
      lst_train.put(name, t);
      //trains.put(name, new Train(name));
    }
    Train t = lst_train.get(name);
    // Change this method!
    return t;
  }
}

