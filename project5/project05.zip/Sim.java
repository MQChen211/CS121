import java.io.*;
import java.util.*;
import java.lang.*;
import static java.lang.Thread.sleep;

public class Sim {

  public static void run_sim(MBTA mbta, Log log) {

    List<Thread> thread_train = new ArrayList<>();
    List<Thread> thread_passenger = new ArrayList<>();
    List<Thread> thread_line = new ArrayList<>();
    List<Thread> thread_journey = new ArrayList<>();
    whenTostop sig = new whenTostop();

    for (Passenger psg : Passenger.lst_passenger.values()) {
      Thread t_passenger = new Thread((Runnable) psg);
      thread_passenger.add(t_passenger);
    }

    for (Train tn : Train.lst_train.values()) {
      Thread t_tn = new Thread((Runnable) tn);
      thread_train.add(t_tn);
    }

    for (Line ln : mbta.tLineSet) {
      Train tname = ln.t_Train;
      thread_line.add(new Thread((Runnable) new threadTrain(log, mbta, tname, sig)));
    }

    for (Journey jny : mbta.pJourneySet) {
      Thread t_jny = new Thread((Runnable) jny);
      thread_journey.add(t_jny);
    }

    for (Thread trd_line : thread_line) {
      trd_line.start();
    }

    for (Thread trd_jny : thread_journey) {
      trd_jny.start();
    }


  }


  public static void main(String[] args) throws Exception {
    if (args.length != 1) {
      System.out.println("usage: ./sim <config file>");
      System.exit(1);
    }

    MBTA mbta = new MBTA();
    mbta.loadConfig(args[0]);

    Log log = new Log();

    run_sim(mbta, log);

    String s = new LogJson(log).toJson();
    PrintWriter out = new PrintWriter("log.json");
    out.print(s);
    out.close();

    mbta.reset();
    mbta.loadConfig(args[0]);
    Verify.verify(mbta, log);
  }
}


// in order to avoid crush, each train has a lock

// line thread order 2??
//          synchronized (tnxt){
//            if(t.station_nxt.isNoTrain_inStation == false){
//              try {
//                t.station_nxt.wait();
//              } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//              }
//            }
//
//            t.station_nxt.isNoTrain_inStation = false;
//            t.station_cur.isNoTrain_inStation = true;
//
//            synchronized (tcur){
//              Thread.sleep(500);
//            }
//
//            log.train_moves(t, t.station_cur, t.station_nxt);
//            t.station_cur.notify();
//            t.station_cur = t.station_nxt;
//
//          }