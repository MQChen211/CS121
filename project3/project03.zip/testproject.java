public class testproject {

    @Test
    public void test01(){System.out.println("This is test 01");}

    @Test
    public void test02(){System.out.println("This is test 02");}

    @Before
    public static void before01(){System.out.println("This is before 01");}

    @Before
    public static void before02(){System.out.println("This is before 02");}

    @BeforeClass
    public static void beforeclas01(){System.out.println("This is beforeclass 01");}

    @BeforeClass
    public static void beforeclass02(){System.out.println("This is beforeclass 02");}

    @After
    public static void after01(){System.out.println("This is after 01");}

    @After
    public static void after02(){System.out.println("This is after 02");}

    @AfterClass
    public static void afterclass01(){System.out.println("This is afterclass 01");}

    @AfterClass
    public static void afterclass02(){System.out.println("This is afterclass 02");}

    @Property
    public static boolean testInt(@IntRange(min=1, max=2) int i1, @IntRange(min=2, max=4) int i2) {
        return i1 <= i2;
    }

}
