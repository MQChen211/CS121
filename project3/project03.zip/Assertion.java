public class Assertion {

    static AssertionObject assertThat(Object o) {
        AssertionObject obj = new AssertionObject(o);
        return obj;
        //return new AssertionObject(o);
    }

    static AssertionString assertThat(String s) {
        AssertionString str = new AssertionString(s);
        return str;
//return new AssertionBoolean(b);
    }

    static AssertionBoolean assertThat(boolean b) {
        AssertionBoolean boo = new AssertionBoolean(b);
        return boo;
//return new AssertionBoolean(b);
    }

    static AssertionInteger assertThat(int i) {
        AssertionInteger aint = new AssertionInteger(i);
        return aint;
        //return new AssertionInteger(i);
    }
}





class AssertionObject{
    Object obj;
    AssertionObject(Object o){
        this.obj = o;
    }

    public AssertionObject isNotNull(){
            if (this.obj == null) {
                throw new UnsupportedOperationException();
            }
            return this;
    }


    public AssertionObject isNull(){
        if (obj != null) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionObject isEqualTo (Object o2){
        if (!obj.equals(o2)) {
            throw new UnsupportedOperationException();
        }
        return this;
    }


    public AssertionObject isNotEqualTo (Object o2){
        if (obj.equals(o2)) {
            throw new UnsupportedOperationException();
        }
        return this;
    }


    public AssertionObject isInstanceOf (Class c1){
        if (!c1.isInstance(obj)) {
            //if(obj.getClass() == c1.getClass()){
            throw new UnsupportedOperationException();
        }
        return this;
    }
}

class AssertionString{
    String str;
    AssertionString(String s){
        this.str = s;
    }

    public AssertionString isNotNull(){
        if(str == null) {
            throw new UnsupportedOperationException();
        }
        return this;
    }
    public AssertionString isNull(){
        if(str != null) {
            throw new UnsupportedOperationException();
        }
        return this;
    }
    public AssertionString isEqualTo(String s2){
        if(!str.equals(s2)) {
            throw new UnsupportedOperationException();
        }
        return this;
    }
    public AssertionString isNotEqualTo(String s2){
        if(str.equals(s2)) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionString startsWith(String s2){
        if(!str.startsWith(s2)) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionString isEmpty(){
        if(!str.isEmpty()) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionString contains(String s2){
        if(!str.contains(s2)){
            throw new UnsupportedOperationException();
        }
        return this;
    }
}

class AssertionInteger{
    int asInt;
    AssertionInteger(int i){
        this.asInt = i;
    }

    public AssertionInteger isEqualTo(int i2){
        if(asInt != i2) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionInteger isLessThan(int i2){
        if(asInt >= i2) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionInteger isGreaterThan(int i2){
        if(asInt <= i2) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

}

//public class AssertionBoolean {
class AssertionBoolean{
    Boolean boo;
    //public static Object obj;
    AssertionBoolean(Boolean b){
        this.boo = b;
    }

    public AssertionBoolean isEqualTo(Boolean b2){
        if(boo != b2) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionBoolean isTrue(){
        if(boo == false) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

    public AssertionBoolean isFalse(){
        if(boo == true) {
            throw new UnsupportedOperationException();
        }
        return this;
    }

}








