import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.*;
import java.lang.reflect.InvocationTargetException;

public class Unit {
    public static Map<String, Throwable> testClass(String name) {

        Map<String, Throwable> testingMap = new HashMap<String, Throwable>();//String == m.getName()
        /*
        ArrayList<Method> BeforeClass = new ArrayList<Method>();
        ArrayList<Method> Before = new ArrayList<Method>();
        ArrayList<Method> Test = new ArrayList<Method>();
        ArrayList<Method> After = new ArrayList<Method>();
        ArrayList<Method> AfterClass = new ArrayList<Method>();
        */
        ArrayList<String> BeforeClass = new ArrayList<>();
        ArrayList<String> Before = new ArrayList<>();
        ArrayList<String> Test = new ArrayList<>();
        ArrayList<String> After = new ArrayList<>();
        ArrayList<String> AfterClass = new ArrayList<>();
        // declare 5 lists to keep methods with corresponding annotation
        ArrayList<String> allMethodsnames = new ArrayList<>();


        // returns the Class object for this class
        Class curClass = null;
        try {
            curClass = Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Class represented by curClass: " + curClass.toString());
        //ArrayList<String> methodsDesciption = curClass.getDeclaredMethods();

        Object object = null;
        try {
            object = curClass.getDeclaredConstructor().newInstance();
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        //new instance

        Method[] allMethods = curClass.getDeclaredMethods();//return method type array
        //Collections.sort(allMethods);


        for (Method m : allMethods) {
            allMethodsnames.add(m.getName());
        }


        for (Method m : allMethods) {
            Annotation ifBeforeClass = m.getAnnotation(BeforeClass.class);
            Annotation ifBefore = m.getAnnotation(Before.class);
            Annotation ifTest = m.getAnnotation(Test.class);
            Annotation ifAfter = m.getAnnotation(After.class);
            Annotation ifAfterClass = m.getAnnotation(AfterClass.class);
            //https://www.geeksforgeeks.org/class-getmethod-method-in-java-with-examples/

            if (m.getAnnotations().length > 1) {
                throw new UnsupportedOperationException();
            }

            if (ifBeforeClass != null) {
                //String nameBC = m.getName();
                //BeforeClass.add(nameBC);
                //BeforeClass.add(m);
                BeforeClass.add(m.getName());
            } else if (ifBefore != null) {
                //String nameB = m.getName();
                //BeforeClass.add(nameB);
                Before.add(m.getName());
            } else if (ifTest != null) {
                //String nameT = m.getName();
                //BeforeClass.add(nameT);
                Test.add(m.getName());
            } else if (ifAfter != null) {
                //String nameA = m.getName();
                //BeforeClass.add(nameA);
                After.add(m.getName());
            } else if (ifAfterClass != null) {
                //String nameAC = m.getName();
                //BeforeClass.add(nameAC);
                AfterClass.add(m.getName());
            } else throw new NullPointerException();
        }

        Collections.sort(BeforeClass);
        Collections.sort(Before);
        Collections.sort(Test);
        Collections.sort(After);
        Collections.sort(AfterClass);


        for (String s : BeforeClass) {
            Method m = null;
            try {
                m = curClass.getMethod(s);
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            }
            try {
                m.invoke(null);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            } catch (InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        }
        //run all the BeforeClass

        for (String s : Test) {
            Method mt = null;
            try {
                mt = curClass.getMethod(s);
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            }

            for (String sb : Before) {
                Method m = null;
                try {
                    m = curClass.getMethod(sb);
                } catch (NoSuchMethodException e) {
                    throw new RuntimeException(e);
                }
                //b.invoke(object, (Object[]) null);
                try {
                    m.invoke(object);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }//invoke method with Before annotation


            //invoke method with Test annotation
            //testingMap.put(s, null);
            try {
                mt.invoke(object);
                testingMap.put(s, null);
            } catch (Exception e) {
                Throwable cause = e.getCause();
                testingMap.put(s, e);
            }


            for (String s2 : After) {
                //a.invoke(object, (Object[]) null);
                Method ma = null;
                try {
                    ma = curClass.getMethod(s2);
                } catch (NoSuchMethodException e) {
                    throw new RuntimeException(e);
                }
                try {
                    ma.invoke(object);
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                }
            }//invoke method with After annotation
        }
        //each test, run all the Before and all the After


        for (String saa : AfterClass) {
            Method maa = null;
            try {
                maa = curClass.getMethod(saa);
            } catch (NoSuchMethodException e) {
                throw new RuntimeException(e);
            }
            try {
                maa.invoke(null);
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            } catch (InvocationTargetException e) {
                throw new RuntimeException(e);
            }
        }
        //run all the AfterClass

        return testingMap;
    }


    public static Map<String, Object[]> quickCheckClass(String name) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Map<String, Object[]> checkMap = new HashMap<>();//String == m.getName()
        HashMap<String, Throwable> part2Map = new HashMap<String, Throwable>();

        List<String> PropertyClass = new ArrayList<>();
        List<Method> mProperty = new ArrayList<>();
        List<Method> sortedMethod = new ArrayList<>();
        List<?> paras = new ArrayList<>();//parameters array
        List<List<?>> allParaPositions = new ArrayList<>();
        Class curClass = Class.forName(name);
        Object object = curClass.getDeclaredConstructor().newInstance();
        Method[] allMethods = curClass.getDeclaredMethods();//return method type array

        int count = 1;

        for (Method m : allMethods) {
            Annotation ifProperty = m.getAnnotation(Property.class);
            if (ifProperty != null) {
                PropertyClass.add(m.getName()); //array of method names string
                mProperty.add(m); //array of methods
            }
        }
        Collections.sort(PropertyClass);//get methods names annotated with @property\

        for (Method m : mProperty) {
            for (String s : PropertyClass) {
                if (m.getName().equals(s)) {
                    sortedMethod.add(m);
                }
            }
        }
        // This loop sorts methods


        for (Method m : sortedMethod) {
            Parameter[] plist = m.getParameters(); //return a method's parameters as a list
            int argLength = plist.length;
            for (Parameter p : plist) {
                Annotation[] anolist = p.getAnnotations(); //return a method's para's annotations as a list
                for (Annotation a : anolist) {

                    if(a instanceof IntRange){
                        allParaPositions.add(ifIntRange(a,m,object));

                    }

                    if(a instanceof StringSet){
                        allParaPositions.add(ifStringSet(a,m,object));
                    }

                    if(a instanceof ListLength){
                        allParaPositions.add(ifListLength(a,m,object));
                    }

                    if(a instanceof ForAll){
                        allParaPositions.add((ifForAll(a,m,object)));

                    }
                    //***************pos of the 3nd comment*************
                    //allParaPositions.add(MtdLst);
                    //return sublist;
                }
            }
            checkMap.put(m.getName(), null);
            //part2Map.put(m.getName(), null);
            //***************************************************
        }

/*
        for(Method m: sortedMethod){
            Parameter[] objPara = m.getParameters();
            Annotation[][] objAno = m.getParameterAnnotations();

            m.invoke(object);

        }
        */

        return checkMap;
        //return part2Map;

        //checkMap.put(m.getName(), null);
    }


    //public static List getCombination(Annotation a, Method m, Object o) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {


    public static List ifIntRange(Annotation a, Method m, Object o) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        List sublist = new ArrayList<>();
        int count = 0;
        if (a instanceof IntRange) {
            IntRange intRange = (IntRange) a;
            //int min = intRange.min();
            //int max = intRange.max();
            int min = (Integer) a.annotationType().getMethod("min").invoke(a);
            int max = (Integer) a.annotationType().getMethod("man").invoke(a);
            System.out.println(" This is IntRange type");
            for (int i = min; i < max; i++) {
                m.invoke(m.getName(),o);
                sublist.add(i);
            }
            //allParaPositions.add(sublist);
        }
        return sublist;
    }

    public static List ifStringSet(Annotation a, Method m, Object o) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        List sublist = new ArrayList<>();
        if (a instanceof StringSet) {
            StringSet strset = (StringSet) a;
            String[] stringSet = (String[]) a.annotationType().getMethod("String").invoke(a);
            System.out.println(" This is StringSet type");
            for (String s : strset.strings()) {
                m.invoke(m.getName(),o);
                sublist.add(s);
            }
            //allParaPositions.add(sublist);
        }
        return sublist;
    }

    public static List ifListLength(Annotation a, Method m, Object o) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        List sublist = new ArrayList<>();
        if (a instanceof ListLength) {
            ListLength lstLen = (ListLength) a;
            int min = (Integer) a.annotationType().getMethod("min").invoke(a);
            int max = (Integer) a.annotationType().getMethod("man").invoke(a);
            System.out.println(" This is ListLength type");
            for (int i = lstLen.min(); i <= lstLen.max(); i++) {
                m.invoke(m.getName(),o);
                sublist.add(i);
            }
            //allParaPositions.add(sublist);
        }
        return sublist;
    }


    public static List ifForAll(Annotation a, Method m, Object o) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        List sublist = new ArrayList<>();
        if (a instanceof ForAll) {
            ForAll forAll = (ForAll) a;
            String strName = forAll.name();
            int strTime = forAll.times();
            String names = (String) a.annotationType().getMethod("name").invoke(a);
            int times = (Integer) a.annotationType().getMethod("times").invoke(a);
            System.out.println(" This is ForAll type");
            for (int t = 0; t < forAll.times(); t++) {
                try {
                    m.invoke(m.getName(),o);
                    sublist.add(a.annotationType().getMethod("name").invoke(a));
                } catch (IllegalAccessException e) {
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e) {
                    throw new RuntimeException(e);
                } catch (NoSuchMethodException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        return sublist;
    }
    //}




    }















/*
    public static List quickCheckClass(String name) {
        Map<String, Object[]> checkMap = new HashMap<>();//String == m.getName()
        //Unit p2unit = new Unit();
        List<String> PropertyClass = new ArrayList<>();
        List<Method> mProperty = new ArrayList<>();
        List<Method> sortedMethod = new ArrayList<>();
        List<?> paras = new ArrayList<>();//parameters array
        List<List<?>> allParaPositions = new ArrayList<>();
        // returns the Class object for this class
        Class curClass = null;
        try {
            curClass = Class.forName(name);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        try {
            Object object = curClass.getDeclaredConstructor().newInstance();      //new instance
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
        Method[] allMethods = curClass.getDeclaredMethods();//return method type array

        for (Method m : allMethods) {
            Annotation ifProperty = m.getAnnotation(Property.class);
            if (ifProperty != null) {
                PropertyClass.add(m.getName()); //array of method names string
                mProperty.add(m); //array of methods
            }
        }
        Collections.sort(PropertyClass);//get methods names annotated with @property\

        for (Method m : mProperty) {
            for (String s : PropertyClass) {
                if (m.getName().equals(s)) {
                    sortedMethod.add(m);
                }
            }
        }
        // This loop sorts methods

        List sublist = new ArrayList<>();
        for (Method m : sortedMethod) {
            Parameter[] plist = m.getParameters(); //return a method's parameters as a list
            int argLength = plist.length;
            for (Parameter p : plist) {
                Annotation[] anolist = p.getAnnotations(); //return a method's para's annotations as a list
                for (Annotation a : anolist) {
                    //getParaSublist(a, m, object);
                    //***************pos of the 3nd comment*************
                    if (a instanceof IntRange) {
                        IntRange intRange = (IntRange) a;
                        int min = intRange.min();
                        int max = intRange.max();
                        //int min = (Integer) a.annotationType().getMethod("min").invoke(a);
                        //int max = (Integer) a.annotationType().getMethod("man").invoke(a);
                        System.out.println(" This is IntRange type");
                        for (int i = min; i < max; i++) {
                            sublist.add(i);
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }

                    if (a instanceof StringSet) {
                        StringSet strset = (StringSet) a;
                        //String[] stringSet = (String[]) a.annotationType().getMethod("String").invoke(a);
                        System.out.println(" This is StringSet type");
                        for (String s : strset.strings()) {
                            sublist.add(s);
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }

                    if (a instanceof ListLength) {
                        ListLength lstLen = (ListLength) a;
                        //int min = (Integer) a.annotationType().getMethod("min").invoke(a);
                        //int max = (Integer) a.annotationType().getMethod("man").invoke(a);
                        System.out.println(" This is ListLength type");
                        for (int i = lstLen.min(); i <= lstLen.max(); i++) {
                            sublist.add(i);
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }


                    if (a instanceof ForAll) {
                        ForAll forAll = (ForAll) a;
                        String strName = forAll.name();
                        int strTime = forAll.times();
                        //String names = (String) a.annotationType().getMethod("name").invoke(a);
                        //int times = (Integer) a.annotationType().getMethod("times").invoke(a);
                        System.out.println(" This is ForAll type");
                        for (int t = 0; t < forAll.times(); t++) {
                            try {
                                sublist.add(a.annotationType().getMethod("name").invoke(a));
                            } catch (IllegalAccessException e) {
                                throw new RuntimeException(e);
                            } catch (InvocationTargetException e) {
                                throw new RuntimeException(e);
                            } catch (NoSuchMethodException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }
                    else throw new NullPointerException();
                }
                    //***************************************************
                }

                checkMap.put(m.getName(), null);
            }
        return (List) checkMap;
        }

    }*/

/*
    //This method gets sublist of method
    public static List getParaSublist(Annotation a, Method m, Object o) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {

        List sublist = new ArrayList<>();

        if (a instanceof IntRange) {
            IntRange intRange = (IntRange) a;
            int min = intRange.min();
            int max = intRange.max();
            //int min = (Integer) a.annotationType().getMethod("min").invoke(a);
            //int max = (Integer) a.annotationType().getMethod("man").invoke(a);
            System.out.println(" This is IntRange type");
            for (int i = min; i < max; i++) {
                sublist.add(i);
            }
            return sublist;
        }

        if (a instanceof StringSet) {
            StringSet strset = (StringSet) a;
            //String[] stringSet = (String[]) a.annotationType().getMethod("String").invoke(a);
            System.out.println(" This is StringSet type");


            for (String s : strset.strings()) {
                sublist.add(s);
            }
            return sublist;
        }

        if (a instanceof ListLength) {
            ListLength lstLen = (ListLength) a;
            //int min = (Integer) a.annotationType().getMethod("min").invoke(a);
            //int max = (Integer) a.annotationType().getMethod("man").invoke(a);
            System.out.println(" This is ListLength type");
            for (int i = lstLen.min(); i <= lstLen.max(); i++) {
                sublist.add(i);
            }
            return sublist;
        }


        if (a instanceof ForAll) {
            ForAll forAll = (ForAll) a;
            String strName = forAll.name();
            int strTime = forAll.times();
            //String names = (String) a.annotationType().getMethod("name").invoke(a);
            //int times = (Integer) a.annotationType().getMethod("times").invoke(a);
            System.out.println(" This is ForAll type");
            for (int t = 0; t < forAll.times(); t++) {
                sublist.add(a.annotationType().getMethod("name").invoke(a));
            }
            return sublist;
        }
        else throw new NullPointerException();
    }*/








        /*
        for (Method m: BeforeClass){
            m.invoke(null);
        }
        //run all the BeforeClass

        for(Method m: Test){

            for(Method b: Before){
                //b.invoke(object, (Object[]) null);
                b.invoke(object);
            }//invoke method with Before annotation

            //invoke method with Test annotation
            testingMap.put(m.getName(), null);
            try{
                m.invoke(object);
            }
            catch (Exception e){
                testingMap.put(m.getName(), e);
            }


            for(Method a: After){
                //a.invoke(object, (Object[]) null);
                a.invoke(object);
            }//invoke method with After annotation
        }
        //each test, run all the Before and all the After


        for (Method m: AfterClass){
            m.invoke(null);
        }
        //run all the AfterClass

        return testingMap;
    }

    */









/*
        for (Method m : allMethods) {
            for (String s : PropertyClass) {
                if (m.getName().equals(s)) {
                    Parameter[] plist = m.getParameters(); //return a method's parameters as a list
                    for (Parameter p : plist) {
                        Annotation[] anolist = p.getAnnotations(); //return a method's para's annotations as a list
                        for(Annotation a: anolist){

                            if(a instanceof IntRange){
                                System.out.println(" This is IntRange type");
                                p2unit.ifInteger();

                            }
                            else if(a instanceof StringSet){
                                System.out.println(" This is StringSet type");
                                p2unit.ifString();
                            }
                            else if(a instanceof ListLength){
                                System.out.println(" This is ListLength type");
                                p2unit.ifList();
                            }
                            else if(a instanceof ForAll){
                                System.out.println(" This is ForAll type");
                                p2unit.ifObject();
                            }
                            else{
                                throw new UnsupportedOperationException();
                            }


                        }
                    }
                }
            }//get @property methods in alphabetic order
        }

        return checkMap;

    }

 */






                    /*
                    if (a instanceof IntRange) {
                        IntRange intRange = (IntRange) a;
                        int min = intRange.min();
                        int max = intRange.max();
                        //int min = (Integer) a.annotationType().getMethod("min").invoke(a);
                        //int max = (Integer) a.annotationType().getMethod("man").invoke(a);
                        System.out.println(" This is IntRange type");
                        p2unit.ifInteger();

                        for(int i = min; i < max; i++ ){
                            sublist.add(i);
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }

                    if (a instanceof StringSet) {
                        StringSet strset = (StringSet) a;
                        //String[] stringSet = (String[]) a.annotationType().getMethod("String").invoke(a);
                        System.out.println(" This is StringSet type");
                        p2unit.ifString();

                        for(String s: strset.strings()){
                            sublist.add(s);
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }

                    if (a instanceof ListLength) {
                        ListLength lstLen = (ListLength) a;
                        //int min = (Integer) a.annotationType().getMethod("min").invoke(a);
                        //int max = (Integer) a.annotationType().getMethod("man").invoke(a);
                        System.out.println(" This is ListLength type");
                        p2unit.ifList();
                        for(int i = lstLen.min(); i <= lstLen.max(); i++){
                            sublist.add(i);
                        }
                        allParaPositions.add(sublist);
                        return sublist;

                    }


                    if (a instanceof ForAll) {
                        ForAll forAll = (ForAll) a;
                        String strName = forAll.name();
                        int strTime = forAll.times();
                        //String names = (String) a.annotationType().getMethod("name").invoke(a);
                        //int times = (Integer) a.annotationType().getMethod("times").invoke(a);
                        System.out.println(" This is ForAll type");
                        p2unit.ifObject();

                        for (int t = 0; t < forAll.times(); t++) {
                            sublist.add(a.annotationType().getMethod("name").invoke(a));
                        }
                        allParaPositions.add(sublist);
                        return sublist;
                    }
                    */



     /*
        for (Method m: BeforeClass){
            m.invoke(null);
        }
        //run all the BeforeClass

        for(Method m: Test){

            for(Method b: Before){
                //b.invoke(object, (Object[]) null);
                b.invoke(object);
            }//invoke method with Before annotation

            //invoke method with Test annotation
            testingMap.put(m.getName(), null);
            try{
                m.invoke(object);
            }
            catch (Exception e){
                testingMap.put(m.getName(), e);
            }


            for(Method a: After){
                //a.invoke(object, (Object[]) null);
                a.invoke(object);
            }//invoke method with After annotation
        }
        //each test, run all the Before and all the After


        for (Method m: AfterClass){
            m.invoke(null);
        }
        //run all the AfterClass

        return testingMap;
    }

    */



//https://stackoverflow.com/questions/15868914/how-to-get-2d-array-possible-combinations/15869610
//https://www.geeksforgeeks.org/method-class-getparameterannotations-method-in-java/
//https://www.javatpoint.com/java-method-getparameterannotations-method
//https://docs.oracle.com/javase/8/docs/api/java/lang/reflect/Method.html
//http://www.java2s.com/example/java-api/java/lang/reflect/method/getparameters-0-0.html
//https://runestone.academy/ns/books/published/csjava/Unit9-2DArray/a2dSummary.html
//https://www.tabnine.com/code/java/methods/java.lang.reflect.Method/getParameters
//https://blog.csdn.net/qq_27397913/article/details/102475475
//https://blog.csdn.net/abcwywht/article/details/78143314
//https://cloud.tencent.com/developer/article/1653598